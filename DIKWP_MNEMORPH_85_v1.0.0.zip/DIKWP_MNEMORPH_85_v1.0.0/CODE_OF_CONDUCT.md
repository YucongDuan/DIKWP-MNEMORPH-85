# Code of Conduct

Critique artifacts, claims and mechanisms. Do not assign permanent moral, humanity or personhood labels to contributors or users. Preserve the right to challenge memory reconstructions and to correct the public record.
