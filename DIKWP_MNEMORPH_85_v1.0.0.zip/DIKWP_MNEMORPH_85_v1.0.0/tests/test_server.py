from __future__ import annotations

import json
import socket
import tempfile
from pathlib import Path
import threading
import time
import unittest
from urllib.request import Request, urlopen
from urllib.error import HTTPError

from http.server import ThreadingHTTPServer

from mnemorph85.server import App, Handler


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.tmp = tempfile.TemporaryDirectory()
        cls.port = free_port()
        root = Path(__file__).resolve().parents[1]
        cls.server = ThreadingHTTPServer(("127.0.0.1", cls.port), Handler)
        cls.server.app = App(root, Path(cls.tmp.name) / "server.db")  # type: ignore[attr-defined]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        time.sleep(0.2)

    @classmethod
    def tearDownClass(cls) -> None:
        cls.server.shutdown()
        cls.server.server_close()
        cls.tmp.cleanup()

    def get_json(self, path: str) -> dict:
        with urlopen(f"http://127.0.0.1:{self.port}{path}") as r:
            return json.loads(r.read().decode())

    def post_json(self, path: str, payload: dict) -> dict:
        req = Request(
            f"http://127.0.0.1:{self.port}{path}",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urlopen(req) as r:
            return json.loads(r.read().decode())

    def test_health(self) -> None:
        data = self.get_json("/api/health")
        self.assertEqual(data["status"], "ok")
        self.assertTrue(data["audit"]["valid"])

    def test_index(self) -> None:
        with urlopen(f"http://127.0.0.1:{self.port}/") as r:
            body = r.read().decode()
            self.assertIn("MNEMORPH-85", body)
            self.assertEqual(r.headers.get("X-Frame-Options"), "DENY")

    def test_summary(self) -> None:
        data = self.get_json("/api/summary")
        self.assertGreaterEqual(data["counts"]["traces"], 6)

    def test_reconstruct_endpoint(self) -> None:
        data = self.post_json("/api/reconstruct", {
            "carrier_id": "demo-continuity",
            "query": "下一步是什么？",
            "context": {"resource_state": "limited"},
            "purpose": "choose"
        })
        self.assertEqual(data["dikwp"]["semantic_continuity"]["vector"], "11111")

    def test_record_endpoint(self) -> None:
        data = self.post_json("/api/records", {
            "carrier_id": "demo-continuity", "content": "new trace", "trace_kind": "world_effect", "polarity": "revise"
        })
        self.assertIn("record", data)

    def test_model_context_endpoint(self) -> None:
        data = self.post_json("/api/model/context", {"carrier_id": "demo-continuity", "query": "what now?"})
        self.assertTrue(data["adapter_contract"]["silent_memory_write_forbidden"])

    def test_unauthorized_write_returns_403(self) -> None:
        req = Request(
            f"http://127.0.0.1:{self.port}/api/records",
            data=json.dumps({"carrier_id": "x", "content": "bad", "authorized": False}).encode(),
            headers={"Content-Type": "application/json"}, method="POST",
        )
        with self.assertRaises(HTTPError) as ctx:
            urlopen(req)
        self.assertEqual(ctx.exception.code, 403)

    def test_audit_endpoint(self) -> None:
        data = self.get_json("/api/audit/verify")
        self.assertTrue(data["valid"])


if __name__ == "__main__":
    unittest.main()
