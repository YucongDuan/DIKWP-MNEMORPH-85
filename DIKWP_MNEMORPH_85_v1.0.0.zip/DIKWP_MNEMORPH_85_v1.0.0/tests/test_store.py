from __future__ import annotations

import tempfile
from pathlib import Path
import unittest

from mnemorph85.core import MemoryEngine
from mnemorph85.store import MemoryStore


class StoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.store = MemoryStore(Path(self.tmp.name) / "test.db")
        self.engine = MemoryEngine(self.store)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_audit_chain(self) -> None:
        self.engine.ensure_carrier("c1")
        self.engine.ingest_record("c1", "x")
        result = self.store.verify_audit()
        self.assertTrue(result["valid"])
        self.assertGreaterEqual(result["event_count"], 3)

    def test_reset(self) -> None:
        self.engine.bootstrap_demo(reset=True)
        self.store.reset()
        self.assertEqual(sum(self.store.counts().values()), 0)

    def test_carrier_upsert(self) -> None:
        self.engine.ensure_carrier("c1", "one")
        self.engine.ensure_carrier("c1", "two", "silicon")
        carriers = self.store.list_carriers()
        self.assertEqual(len(carriers), 1)
        self.assertEqual(carriers[0]["label"], "two")
        self.assertEqual(carriers[0]["carrier_kind"], "silicon")

    def test_records_and_traces_are_queryable(self) -> None:
        self.engine.ensure_carrier("c1")
        item = self.engine.ingest_record("c1", "queryable")
        self.assertEqual(self.store.get_record(item["record"]["record_id"])["content"], "queryable")
        self.assertEqual(self.store.get_trace(item["trace"]["trace_id"])["content"], "queryable")

    def test_reconstruction_history(self) -> None:
        self.engine.ensure_carrier("c1")
        self.engine.ingest_record("c1", "memory")
        self.engine.reconstruct("c1", "memory")
        self.engine.reconstruct("c1", "memory again")
        self.assertEqual(len(self.store.list_reconstructions("c1")), 2)

    def test_self_state_parent_lineage(self) -> None:
        self.engine.ensure_carrier("c1")
        self.engine.ingest_record("c1", "value", trace_kind="value", tags=["value"])
        a = self.engine.compile_self_state("c1", trigger="a")
        b = self.engine.compile_self_state("c1", trigger="b")
        self.assertEqual(b["parent_state_id"], a["state_id"])

    def test_action_outcome_storage(self) -> None:
        self.engine.bootstrap_demo(reset=True)
        action = self.engine.create_action("demo-continuity", None, "test")
        self.engine.observe_outcome("demo-continuity", action["action_id"], actual_result="done")
        self.assertEqual(len(self.store.list_actions("demo-continuity")), 1)
        self.assertEqual(len(self.store.list_outcomes("demo-continuity")), 1)


if __name__ == "__main__":
    unittest.main()
