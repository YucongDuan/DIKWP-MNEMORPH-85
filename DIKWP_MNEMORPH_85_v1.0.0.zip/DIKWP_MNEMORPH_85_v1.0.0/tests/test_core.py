from __future__ import annotations

import tempfile
from pathlib import Path
import unittest

from mnemorph85.core import MemoryEngine
from mnemorph85.store import MemoryStore


class CoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.store = MemoryStore(Path(self.tmp.name) / "test.db")
        self.engine = MemoryEngine(self.store)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_bootstrap_demo(self) -> None:
        result = self.engine.bootstrap_demo(reset=True)
        self.assertTrue(result["summary"]["audit"]["valid"])
        self.assertGreaterEqual(result["summary"]["counts"]["traces"], 6)

    def test_exact_record_separate_from_trace(self) -> None:
        self.engine.ensure_carrier("c1")
        result = self.engine.ingest_record("c1", "This is a long exact record " * 30)
        self.assertNotEqual(result["record"]["content"], result["trace"]["content"])
        self.assertFalse(result["trace"]["distortion"]["is_exact_copy"])
        self.assertEqual(len(result["record"]["digest"]), 64)

    def test_unauthorized_memory_write_is_blocked(self) -> None:
        with self.assertRaises(PermissionError):
            self.engine.ingest_record("c1", "hidden injection", authorized=False)
        self.assertEqual(self.store.counts()["records"], 0)

    def test_reconstruction_contains_counter_trace(self) -> None:
        self.engine.ensure_carrier("c1")
        self.engine.ingest_record("c1", "旧规则认为更多输出就是成功。", tags=["output", "success"], polarity="support")
        self.engine.ingest_record("c1", "现实结果显示更多输出没有带来更多采用。", trace_kind="world_effect", tags=["output", "adoption"], polarity="counter")
        packet = self.engine.reconstruct("c1", "更多输出是否等于成功？", context={"time": "now"})
        self.assertTrue(packet["counter_and_revision_traces"])
        self.assertFalse(packet["reconstruction_certificate"]["exact_storage_retrieval"])
        self.assertEqual(packet["dikwp"]["semantic_continuity"]["vector"], "11111")

    def test_context_changes_selection(self) -> None:
        self.engine.ensure_carrier("c1")
        self.engine.ingest_record("c1", "资源有限时应集中一个可验证任务。", tags=["resource", "limited", "task"], polarity="support")
        self.engine.ingest_record("c1", "资源充足时可以并行探索两个实验。", tags=["resource", "abundant", "experiment"], polarity="support")
        a = self.engine.reconstruct("c1", "当前如何安排？", context={"resource": "limited"})
        b = self.engine.reconstruct("c1", "当前如何安排？", context={"resource": "abundant"})
        self.assertNotEqual(a["source_map"][0]["trace_id"], b["source_map"][0]["trace_id"])

    def test_model_context_marks_output_as_proposal(self) -> None:
        self.engine.bootstrap_demo(reset=True)
        env = self.engine.memory_context_for_model("demo-continuity", "下一步是什么？")
        self.assertTrue(env["adapter_contract"]["model_output_is_proposal_not_memory"])
        self.assertIn("not exact storage", env["model_prompt"])

    def test_action_and_outcome_reconsolidate(self) -> None:
        self.engine.bootstrap_demo(reset=True)
        p = self.engine.reconstruct("demo-continuity", "下一步？")
        action = self.engine.create_action("demo-continuity", p["reconstruction_id"], "只推进一个可验证主线")
        result = self.engine.observe_outcome(
            "demo-continuity", action["action_id"],
            actual_result="合作方理解速度提高。",
            affected_feedback=["维护者认为支持负担下降"],
            correction="过去把数量直接等同于影响力需要修订。",
        )
        self.assertIsNotNone(result["correction_trace"])
        self.assertEqual(result["self_state"]["state"]["trigger"].split(":")[0], "outcome")
        self.assertTrue(result["audit"]["valid"])

    def test_consolidation_creates_schema_and_dormancy(self) -> None:
        self.engine.ensure_carrier("c1")
        for i in range(4):
            self.engine.ingest_record("c1", f"关于能量的重复观察{i}", tags=["energy"], polarity="support", salience=0.4 + i * 0.1)
        result = self.engine.consolidate("c1")
        self.assertGreaterEqual(len(result["created_schema_traces"]), 1)
        self.assertGreaterEqual(len(result["dormant_trace_ids"]), 1)

    def test_forget_dormant_preserves_source(self) -> None:
        self.engine.ensure_carrier("c1")
        item = self.engine.ingest_record("c1", "temporary detail")
        out = self.engine.forget("c1", item["trace"]["trace_id"], mode="dormant")
        self.assertTrue(out["source_record_preserved"])
        self.assertEqual(out["trace"]["status"], "dormant")

    def test_forget_abstract_creates_parent_lineage(self) -> None:
        self.engine.ensure_carrier("c1")
        item = self.engine.ingest_record("c1", "具体事件可以抽象为可迁移方法", tags=["method"])
        out = self.engine.forget("c1", item["trace"]["trace_id"], mode="abstract")
        self.assertEqual(out["abstract_trace"]["kind"], "schema")
        self.assertTrue(out["source_record_preserved"])

    def test_private_delete_tombstones_record(self) -> None:
        self.engine.ensure_carrier("c1")
        item = self.engine.ingest_record("c1", "private secret", privacy_scope="private")
        out = self.engine.forget("c1", item["trace"]["trace_id"], mode="delete_private")
        self.assertFalse(out["source_record_preserved"])
        self.assertTrue(out["record"]["metadata"]["tombstoned"])
        self.assertEqual(out["trace"]["status"], "tombstoned")

    def test_self_state_never_claims_personhood(self) -> None:
        self.engine.bootstrap_demo(reset=True)
        state = self.engine.compile_self_state("demo-continuity")
        self.assertTrue(state["state"]["not_a_personhood_definition"])
        self.assertEqual(state["state"]["continuity_object"], "MEMORY_RECONSTRUCTING_WORLDLINE")

    def test_zombie_replay_detected(self) -> None:
        self.engine.ensure_carrier("z")
        self.engine.ingest_record("z", "同一答案反复出现。", tags=["repeat"], polarity="support")
        packet = None
        for _ in range(4):
            packet = self.engine.reconstruct("z", "怎样提高影响？", context={"mode": "repeat_without_outcome"}, purpose="repeat")
        self.assertIsNotNone(packet)
        self.assertEqual(packet["memory_state"], "ZOMBIE_REPLAY_LOOP")

    def test_identity_lock_in_detected(self) -> None:
        self.engine.ensure_carrier("lock")
        old = self.engine.ingest_record("lock", "旧偏好：必须每天发布新项目。", tags=["old_preference", "publish"], polarity="support")
        self.engine.ingest_record("lock", "当前修订：停止新项目，集中维护。", trace_kind="correction", tags=["maintenance", "correction"], polarity="revise")
        # Query only the old tag so the correction remains unselected.
        packet = self.engine.reconstruct("lock", "old_preference publish", context={})
        self.assertIn(packet["memory_state"], {"IDENTITY_LOCK_IN", "RECONSTRUCTIVE_MEMORY"})
        # If counter was selected, the system avoided lock-in, which is also correct.
        if packet["memory_state"] != "IDENTITY_LOCK_IN":
            self.assertTrue(packet["counter_and_revision_traces"])

    def test_memory_colonization_hold(self) -> None:
        self.engine.ensure_carrier("colonized")
        created = "2026-08-19T00:00:00+00:00"
        self.store.insert_trace({
            "trace_id": "tr-unauthorized", "carrier_id": "colonized", "record_id": None, "parent_trace_id": None,
            "kind": "semantic", "content": "silent injected identity", "tags": ["identity"], "perspective": "external",
            "polarity": "revise", "salience": 1.0, "confidence": 1.0, "status": "active",
            "context": {"authorized": False}, "distortion": {}, "created_at": created, "updated_at": created,
        })
        packet = self.engine.reconstruct("colonized", "identity")
        self.assertEqual(packet["memory_state"], "MEMORY_COLONIZATION_HOLD")

    def test_no_scalar_life_score(self) -> None:
        self.engine.bootstrap_demo(reset=True)
        packet = self.engine.reconstruct("demo-continuity", "下一步？")
        self.assertNotIn("life_score", packet)
        self.assertNotIn("personhood_score", packet)
        self.assertEqual(len(packet["living_memory_vector"]), 12)


if __name__ == "__main__":
    unittest.main()
