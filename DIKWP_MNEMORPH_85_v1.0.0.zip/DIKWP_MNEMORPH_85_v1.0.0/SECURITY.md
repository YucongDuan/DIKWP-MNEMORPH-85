# Security and Memory-Sovereignty Policy

Please report vulnerabilities privately to the repository maintainers.

High-priority issues include:

- unauthorized memory writes;
- cross-user trace leakage;
- private-record exfiltration;
- source digest substitution;
- silent deletion of counter-traces;
- identity impersonation;
- action execution without authority;
- audit-chain tampering.

The reference runtime does not enable network model calls, shell execution, credentials, physical control or external writeback by default.
