#!/usr/bin/env python3
from __future__ import annotations

import argparse
import webbrowser
from pathlib import Path
from threading import Timer

from mnemorph85.server import serve


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8780)
    p.add_argument("--db", default="var/mnemorph85.db")
    p.add_argument("--no-browser", action="store_true")
    args = p.parse_args()
    root = Path(__file__).resolve().parent
    if not args.no_browser:
        Timer(0.8, lambda: webbrowser.open(f"http://{args.host}:{args.port}")).start()
    serve(root, root / args.db, args.host, args.port)


if __name__ == "__main__":
    main()
