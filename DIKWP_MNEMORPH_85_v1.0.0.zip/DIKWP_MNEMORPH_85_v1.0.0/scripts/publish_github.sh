#!/usr/bin/env bash
set -euo pipefail
OWNER="${1:?owner required}"
REPO="${2:-DIKWP-MNEMORPH-85}"
make qa
if gh repo view "$OWNER/$REPO" >/dev/null 2>&1; then
  git remote remove origin 2>/dev/null || true
  git remote add origin "https://github.com/$OWNER/$REPO.git"
else
  gh repo create "$OWNER/$REPO" --public --description "Reconstructive memory and living continuity runtime for LLMs and agents" --source=. --remote=origin
fi
git add .
git commit -m "Release MNEMORPH-85 v1.0.0" || true
git branch -M main
git push -u origin main
git tag -f v1.0.0
git push -f origin v1.0.0
gh release create v1.0.0 --title "MNEMORPH-85 v1.0.0" --notes "Storage is not memory. Output is a proposal. The world controls reconsolidation." || true
