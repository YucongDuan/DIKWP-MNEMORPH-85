from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from .core import MemoryEngine, SYSTEM_NAME, SYSTEM_NAME_ZH, VERSION
from .server import serve
from .store import MemoryStore


def dump(obj: object, out: str | None = None) -> None:
    text = json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True)
    if out:
        Path(out).parent.mkdir(parents=True, exist_ok=True)
        Path(out).write_text(text, encoding="utf-8")
    else:
        print(text)


def engine(args: argparse.Namespace) -> MemoryEngine:
    store = MemoryStore(args.db)
    eng = MemoryEngine(store)
    if not store.list_carriers():
        eng.bootstrap_demo()
    return eng


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="mnemorph85", description=f"{SYSTEM_NAME_ZH} {VERSION}")
    p.add_argument("--db", default="var/mnemorph85.db", help="SQLite database path")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("summary")
    d = sub.add_parser("demo")
    d.add_argument("--reset", action="store_true")
    d.add_argument("--out")

    i = sub.add_parser("ingest")
    i.add_argument("carrier_id")
    i.add_argument("content")
    i.add_argument("--kind", default="observation")
    i.add_argument("--trace-kind", default="episodic")
    i.add_argument("--tags", default="")
    i.add_argument("--polarity", default="support")
    i.add_argument("--perspective", default="first_party")
    i.add_argument("--out")

    r = sub.add_parser("reconstruct")
    r.add_argument("carrier_id")
    r.add_argument("query")
    r.add_argument("--context", default="{}")
    r.add_argument("--purpose", default="understand_and_act")
    r.add_argument("--affected", default="")
    r.add_argument("--out")

    m = sub.add_parser("model-context")
    m.add_argument("carrier_id")
    m.add_argument("query")
    m.add_argument("--context", default="{}")
    m.add_argument("--purpose", default="answer_with_continuity")
    m.add_argument("--out")

    c = sub.add_parser("consolidate")
    c.add_argument("carrier_id")
    c.add_argument("--out")

    f = sub.add_parser("forget")
    f.add_argument("carrier_id")
    f.add_argument("trace_id")
    f.add_argument("--mode", choices=["dormant", "abstract", "delete_private"], default="dormant")
    f.add_argument("--reason", default="selective_forgetting")
    f.add_argument("--out")

    a = sub.add_parser("act")
    a.add_argument("carrier_id")
    a.add_argument("action_text")
    a.add_argument("--reconstruction-id")
    a.add_argument("--owner", default="memory_steward")
    a.add_argument("--deadline")
    a.add_argument("--out")

    o = sub.add_parser("observe")
    o.add_argument("carrier_id")
    o.add_argument("action_id")
    o.add_argument("actual_result")
    o.add_argument("--feedback", default="")
    o.add_argument("--correction")
    o.add_argument("--future-action")
    o.add_argument("--out")

    s = sub.add_parser("serve")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=8780)
    s.add_argument("--root", default=None, help="Static UI root; defaults to packaged resources")

    sub.add_parser("verify-audit")
    sub.add_parser("selftest")
    return p


def selftest(eng: MemoryEngine) -> dict[str, object]:
    results: dict[str, object] = {}
    summary = eng.summary()
    results["summary"] = summary["status"] == "ok"
    packet = eng.reconstruct(
        "demo-continuity",
        "当前应该继续过去的高输出模式吗？",
        context={"resource_state": "limited", "time": "now"},
        purpose="choose_energy_responsible_action",
        affected_worlds=["持续载体", "合作方"],
    )
    results["reconstruction_not_copy"] = packet["reconstruction_certificate"]["exact_storage_retrieval"] is False
    results["counter_trace_present"] = bool(packet["counter_and_revision_traces"])
    action = eng.create_action("demo-continuity", packet.get("reconstruction_id"), packet["primary_action"]["primary_action"])
    outcome = eng.observe_outcome(
        "demo-continuity",
        action["action_id"],
        actual_result="减少重复发布后，外部合作方更快理解主线，维护负担下降。",
        affected_feedback=["合作方表示入口更清晰。"],
        correction="过去把高产出直接等同于高影响，需要被修订。",
    )
    results["world_effect_reconsolidated"] = bool(outcome["correction_trace"])
    results["audit_valid"] = eng.store.verify_audit()["valid"]
    passed = all(bool(v) for v in results.values())
    return {"system": SYSTEM_NAME, "version": VERSION, "passed": passed, "checks": results}


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    eng = engine(args)
    if args.cmd == "summary":
        dump(eng.summary())
    elif args.cmd == "demo":
        dump(eng.bootstrap_demo(reset=args.reset), args.out)
    elif args.cmd == "ingest":
        dump(eng.ingest_record(
            args.carrier_id, args.content, kind=args.kind, trace_kind=args.trace_kind,
            tags=[x.strip() for x in args.tags.split(",") if x.strip()],
            polarity=args.polarity, perspective=args.perspective,
        ), args.out)
    elif args.cmd == "reconstruct":
        dump(eng.reconstruct(
            args.carrier_id, args.query, context=json.loads(args.context), purpose=args.purpose,
            affected_worlds=[x.strip() for x in args.affected.split(",") if x.strip()],
        ), args.out)
    elif args.cmd == "model-context":
        dump(eng.memory_context_for_model(args.carrier_id, args.query, context=json.loads(args.context), purpose=args.purpose), args.out)
    elif args.cmd == "consolidate":
        dump(eng.consolidate(args.carrier_id), args.out)
    elif args.cmd == "forget":
        dump(eng.forget(args.carrier_id, args.trace_id, mode=args.mode, reason=args.reason), args.out)
    elif args.cmd == "act":
        dump(eng.create_action(args.carrier_id, args.reconstruction_id, args.action_text, owner=args.owner, deadline=args.deadline), args.out)
    elif args.cmd == "observe":
        dump(eng.observe_outcome(
            args.carrier_id, args.action_id, actual_result=args.actual_result,
            affected_feedback=[x.strip() for x in args.feedback.split(",") if x.strip()],
            correction=args.correction, future_action=args.future_action,
        ), args.out)
    elif args.cmd == "serve":
        root = args.root or str(Path(__file__).resolve().parent / "resources")
        serve(root, args.db, args.host, args.port)
    elif args.cmd == "verify-audit":
        dump(eng.store.verify_audit())
    elif args.cmd == "selftest":
        result = selftest(eng)
        dump(result)
        return 0 if result["passed"] else 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
