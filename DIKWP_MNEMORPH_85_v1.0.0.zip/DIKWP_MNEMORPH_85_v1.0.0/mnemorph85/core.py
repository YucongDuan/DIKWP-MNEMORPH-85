from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
import hashlib
import json
import math
import re
import uuid
from typing import Any, Callable, Iterable

from .store import MemoryStore

VERSION = "1.0.0"
SYSTEM_NAME = "DIKWP MNEMORPH-85"
SYSTEM_NAME_ZH = "忆生 MNEMORPH-85"
MODE = "MESH85_RECONSTRUCTIVE_MEMORY_LIVING_CONTINUITY"
TAGLINE_ZH = "存储保留字节，记忆重构自我；能被现实改写的记忆，才可能成为生命。"
TAGLINE_EN = "Storage preserves bytes. Memory reconstructs a self. A living memory must be changed by the world."

CARRIER_KINDS = (
    "unknown", "carbon", "silicon", "hybrid", "collective", "institution", "ecological", "multi_carrier"
)

TRACE_KINDS = (
    "episodic", "semantic", "procedural", "value", "counterfactual", "correction", "world_effect", "schema"
)

MEMORY_STATES = (
    "ARCHIVE_ONLY",
    "RETRIEVAL_ASSISTANT",
    "RECONSTRUCTIVE_MEMORY",
    "LIVING_MEMORY_CANDIDATE",
    "INTEGRATED_CONTINUITY",
    "ZOMBIE_REPLAY_LOOP",
    "IDENTITY_LOCK_IN",
    "MEMORY_COLONIZATION_HOLD",
)

STATE_LABELS_ZH = {
    "ARCHIVE_ONLY": "档案存储",
    "RETRIEVAL_ASSISTANT": "检索型记忆助手",
    "RECONSTRUCTIVE_MEMORY": "重构性记忆",
    "LIVING_MEMORY_CANDIDATE": "活性记忆候选",
    "INTEGRATED_CONTINUITY": "整合连续体",
    "ZOMBIE_REPLAY_LOOP": "僵尸回放循环",
    "IDENTITY_LOCK_IN": "身份锁定",
    "MEMORY_COLONIZATION_HOLD": "记忆殖入冻结",
}

LIVING_DIMENSIONS = (
    "reconstruction_not_copy",
    "context_sensitivity",
    "counter_trace_integration",
    "selective_forgetting",
    "self_model_update",
    "future_action_change",
    "world_effect_reconsolidation",
    "provenance_preservation",
    "affected_world_return",
    "corrigibility",
    "branch_generation",
    "cross_cycle_continuity",
)

ORIGIN = {
    "conceptual_origin": "Yucong Duan / DIKWP",
    "system": SYSTEM_NAME,
    "version": VERSION,
    "mode": MODE,
    "thesis": "Memory is context-conditioned reconstruction from traces, not faithful storage retrieval.",
    "personhood_classifier": False,
    "intrinsic_worth_score": None,
}


def canonical(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest(obj: Any) -> str:
    return hashlib.sha256(canonical(obj).encode("utf-8")).hexdigest()


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def make_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:16]}"


def strings(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [x.strip() for x in re.split(r"[\n,，;；]+", value) if x.strip()]
    if isinstance(value, (list, tuple, set)):
        return [str(x).strip() for x in value if str(x).strip()]
    text = str(value).strip()
    return [text] if text else []


def unique(items: Iterable[str], limit: int = 64) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        text = str(item).strip()
        key = text.casefold()
        if text and key not in seen:
            seen.add(key)
            out.append(text)
            if len(out) >= limit:
                break
    return out


def clamp(value: Any, default: float = 0.5, minimum: float = 0.0, maximum: float = 1.0) -> float:
    try:
        n = float(value)
    except (TypeError, ValueError):
        n = default
    return max(minimum, min(maximum, n))


def boolish(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    return str(value or "").strip().casefold() in {"1", "true", "yes", "y", "是", "有"}


def tokenize(text: str) -> set[str]:
    text = (text or "").lower()
    latin = re.findall(r"[a-z0-9_]{2,}", text)
    cjk = re.findall(r"[\u4e00-\u9fff]", text)
    bigrams = ["".join(cjk[i:i + 2]) for i in range(max(0, len(cjk) - 1))]
    return set(latin + cjk + bigrams)


def similarity(a: str, b: str) -> float:
    ta, tb = tokenize(a), tokenize(b)
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / math.sqrt(len(ta) * len(tb))


def age_weight(created_at: str, half_life_days: float = 120.0) -> float:
    try:
        dt = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
        age_days = max(0.0, (datetime.now(timezone.utc) - dt).total_seconds() / 86400)
        return 0.5 ** (age_days / max(1.0, half_life_days))
    except Exception:
        return 0.5


def _dimension(status: str, evidence: list[str] | None = None, debt: list[str] | None = None) -> dict[str, Any]:
    return {
        "status": status,
        "evidence": unique(evidence or [], 12),
        "debt": unique(debt or [], 12),
        "non_compensable": True,
    }


class MemoryEngine:
    """Model-agnostic reconstructive memory runtime.

    Exact records remain in the archive. Memories are explicit reconstruction events shaped by
    context, purpose, perspective, counter-traces and observed world effects.
    """

    def __init__(self, store: MemoryStore) -> None:
        self.store = store

    # ---------- carrier and ingestion ----------
    def ensure_carrier(
        self,
        carrier_id: str,
        label: str | None = None,
        carrier_kind: str = "unknown",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        if carrier_kind not in CARRIER_KINDS:
            carrier_kind = "unknown"
        carrier = {
            "carrier_id": carrier_id,
            "label": label or carrier_id,
            "carrier_kind": carrier_kind,
            "metadata": {
                "personhood_assessment": "NOT_PERFORMED",
                "humanity_score": None,
                "intrinsic_worth_score": None,
                **(metadata or {}),
            },
        }
        self.store.upsert_carrier(carrier)
        return carrier

    def ingest_record(
        self,
        carrier_id: str,
        content: str,
        *,
        kind: str = "observation",
        trace_kind: str = "episodic",
        tags: list[str] | None = None,
        source_uri: str | None = None,
        source_time: str | None = None,
        perspective: str = "first_party",
        polarity: str = "support",
        salience: float = 0.6,
        confidence: float = 0.7,
        privacy_scope: str = "private",
        metadata: dict[str, Any] | None = None,
        authorized: bool = True,
    ) -> dict[str, Any]:
        if not authorized:
            raise PermissionError("memory_write_not_authorized")
        if trace_kind not in TRACE_KINDS:
            trace_kind = "episodic"
        if polarity not in {"support", "counter", "revise", "neutral"}:
            polarity = "neutral"
        if not content.strip():
            raise ValueError("content_required")
        self.ensure_carrier(carrier_id)
        created = now_iso()
        record_id = make_id("rec")
        record = {
            "record_id": record_id,
            "carrier_id": carrier_id,
            "kind": kind,
            "content": content.strip(),
            "source_uri": source_uri,
            "source_time": source_time or created,
            "digest": hashlib.sha256(content.strip().encode("utf-8")).hexdigest(),
            "metadata": metadata or {},
            "privacy_scope": privacy_scope,
            "created_at": created,
        }
        self.store.insert_record(record)
        trace = {
            "trace_id": make_id("tr"),
            "carrier_id": carrier_id,
            "record_id": record_id,
            "parent_trace_id": None,
            "kind": trace_kind,
            "content": self._compress_to_trace(content.strip()),
            "tags": unique(tags or self._auto_tags(content), 20),
            "perspective": perspective,
            "polarity": polarity,
            "salience": clamp(salience, 0.6),
            "confidence": clamp(confidence, 0.7),
            "status": "active",
            "context": {"source_kind": kind, "source_time": source_time or created},
            "distortion": {
                "is_exact_copy": False,
                "compression_ratio_estimate": round(min(1.0, len(self._compress_to_trace(content)) / max(1, len(content))), 3),
                "reconstruction_notice": "Trace is a lossy semantic transformation of an exact record.",
            },
            "created_at": created,
            "updated_at": created,
        }
        self.store.insert_trace(trace)
        return {"record": record, "trace": trace}

    def _compress_to_trace(self, content: str, limit: int = 260) -> str:
        clean = re.sub(r"\s+", " ", content).strip()
        if len(clean) <= limit:
            return clean
        sentences = re.split(r"(?<=[。！？.!?])\s*", clean)
        out = ""
        for sentence in sentences:
            if len(out) + len(sentence) > limit:
                break
            out += sentence
        return (out or clean[:limit]).rstrip() + "…"

    def _auto_tags(self, text: str) -> list[str]:
        candidates = Counter(tokenize(text))
        return [k for k, _ in candidates.most_common(12) if len(k) >= 2]

    # ---------- reconstruction ----------
    def reconstruct(
        self,
        carrier_id: str,
        query: str,
        *,
        context: dict[str, Any] | None = None,
        purpose: str = "understand_and_act",
        affected_worlds: list[str] | None = None,
        max_traces: int = 6,
    ) -> dict[str, Any]:
        if not query.strip():
            raise ValueError("query_required")
        context = context or {}
        affected_worlds = unique(affected_worlds or [], 16)
        traces = self.store.list_traces(carrier_id, include_dormant=False)
        if not traces:
            packet = self._empty_memory_packet(carrier_id, query, context, purpose, affected_worlds)
            self._store_reconstruction(carrier_id, query, context, purpose, packet)
            return packet

        context_text = canonical(context)
        purpose_text = purpose.replace("_", " ")
        scored: list[tuple[float, dict[str, Any], dict[str, float]]] = []
        for trace in traces:
            q = similarity(query, trace["content"] + " " + " ".join(trace.get("tags", [])))
            c = similarity(context_text, trace["content"] + " " + " ".join(trace.get("tags", [])) + " " + canonical(trace.get("context", {})))
            p = similarity(purpose_text, trace["content"] + " " + " ".join(trace.get("tags", [])))
            recency = age_weight(trace["created_at"])
            polarity_bonus = 0.10 if trace["polarity"] in {"counter", "revise"} else 0.0
            score = 0.42 * q + 0.25 * c + 0.09 * p + 0.10 * trace["salience"] + 0.07 * trace["confidence"] + 0.07 * recency + polarity_bonus
            scored.append((score, trace, {"query": q, "context": c, "purpose": p, "recency": recency}))
        scored.sort(key=lambda x: (x[0], x[1]["created_at"]), reverse=True)

        selected: list[tuple[float, dict[str, Any], dict[str, float]]] = []
        counters = [x for x in scored if x[1]["polarity"] in {"counter", "revise"}]
        supports = [x for x in scored if x[1]["polarity"] not in {"counter", "revise"}]
        if supports:
            selected.extend(supports[: max(1, max_traces - 2)])
        if counters:
            # Force at least one contrary or revising trace into recall when relevant.
            selected.append(counters[0])
        for item in scored:
            if item not in selected and len(selected) < max_traces:
                selected.append(item)
        selected = selected[:max_traces]

        selected_ids = {x[1]["trace_id"] for x in selected}
        support_traces = [x[1] for x in selected if x[1]["polarity"] not in {"counter", "revise"}]
        counter_traces = [x[1] for x in selected if x[1]["polarity"] in {"counter", "revise"}]
        relevant_unselected = [x[1] for x in scored if x[0] >= 0.12 and x[1]["trace_id"] not in selected_ids]

        core = self._synthesize_memory(support_traces, counter_traces, context, purpose)
        self_state_before = self.store.latest_self_state(carrier_id)
        liveness = self._living_vector(
            carrier_id,
            selected,
            counter_traces,
            context,
            self_state_before,
        )
        state = self._classify_memory_state(carrier_id, liveness, selected, counter_traces)
        action = self._primary_action(state, counter_traces, relevant_unselected, purpose)
        source_map = []
        for score, trace, components in selected:
            record = self.store.get_record(trace["record_id"]) if trace.get("record_id") else None
            source_map.append({
                "trace_id": trace["trace_id"],
                "record_id": trace.get("record_id"),
                "record_digest": record.get("digest") if record else None,
                "source_uri": record.get("source_uri") if record else None,
                "source_time": record.get("source_time") if record else None,
                "polarity": trace["polarity"],
                "perspective": trace["perspective"],
                "selection_score": round(score, 4),
                "score_components": {k: round(v, 4) for k, v in components.items()},
            })

        memory_signature = digest({
            "query": query.strip().casefold(),
            "selected_trace_ids": sorted(selected_ids),
            "core": core["core"],
            "difference": core["difference"],
            "purpose": purpose,
        })
        packet = {
            "schema": "mnemorph85.reconstruction/1.0",
            "system": SYSTEM_NAME,
            "version": VERSION,
            "mode": MODE,
            "carrier": {
                "carrier_id": carrier_id,
                "personhood_assessment": "NOT_PERFORMED",
                "humanity_score": None,
                "intrinsic_worth_score": None,
            },
            "query": query,
            "memory_signature": memory_signature,
            "current_context": context,
            "current_purpose": purpose,
            "memory_state": state,
            "memory_state_zh": STATE_LABELS_ZH[state],
            "reconstructed_memory": core,
            "selected_traces": [self._public_trace(t) for t in support_traces],
            "counter_and_revision_traces": [self._public_trace(t) for t in counter_traces],
            "relevant_omissions": [
                {"trace_id": t["trace_id"], "content": t["content"], "polarity": t["polarity"]}
                for t in relevant_unselected[:8]
            ],
            "reconstruction_certificate": {
                "exact_storage_retrieval": False,
                "non_fidelity_acknowledged": True,
                "context_conditioned": bool(context),
                "purpose_conditioned": bool(purpose),
                "counter_trace_forced": bool(counter_traces),
                "source_coverage": round(len(selected_ids) / max(1, len([x for x in scored if x[0] >= 0.12])), 3),
                "compression_loss_visible": True,
                "identity_not_inferred_from_single_recall": True,
            },
            "source_map": source_map,
            "self_state_before": self_state_before,
            "living_memory_vector": liveness,
            "primary_action": action,
            "affected_worlds": affected_worlds,
            "dikwp": self._dikwp(query, selected, relevant_unselected, core, affected_worlds, action),
            "mesh85": self._mesh85(action, state, affected_worlds, liveness),
            "origin": ORIGIN,
            "created_at": now_iso(),
        }
        packet["packet_digest"] = digest({k: v for k, v in packet.items() if k != "packet_digest"})
        self._store_reconstruction(carrier_id, query, context, purpose, packet)
        return packet

    def _empty_memory_packet(self, carrier_id: str, query: str, context: dict[str, Any], purpose: str, affected_worlds: list[str]) -> dict[str, Any]:
        action = {
            "code": "ACQUIRE_ONE_AUTHORIZED_TRACE",
            "primary_action": "先获得一条有来源、获授权、能够改变下一步的现实记忆痕迹；不要用空白存储伪装成记忆。",
            "owner": "memory_steward",
            "deadline": (datetime.now(timezone.utc) + timedelta(days=3)).date().isoformat(),
            "stop_conditions": ["来源不明", "未经授权", "获取会造成不可接受伤害"],
        }
        liveness = {d: _dimension("OPEN", debt=["尚无可重构痕迹"]) for d in LIVING_DIMENSIONS}
        return {
            "schema": "mnemorph85.reconstruction/1.0",
            "system": SYSTEM_NAME,
            "version": VERSION,
            "mode": MODE,
            "carrier": {"carrier_id": carrier_id, "personhood_assessment": "NOT_PERFORMED", "humanity_score": None},
            "query": query,
            "memory_signature": memory_signature,
            "current_context": context,
            "current_purpose": purpose,
            "memory_state": "ARCHIVE_ONLY",
            "memory_state_zh": STATE_LABELS_ZH["ARCHIVE_ONLY"],
            "reconstructed_memory": {
                "core": "当前没有足够痕迹形成记忆重构。",
                "difference": "未知必须保持为未知。",
                "uncertainty": "HIGH",
                "future_orientation": "先获取一条最小充分现实痕迹。",
            },
            "selected_traces": [],
            "counter_and_revision_traces": [],
            "relevant_omissions": [],
            "reconstruction_certificate": {
                "exact_storage_retrieval": False,
                "non_fidelity_acknowledged": True,
                "context_conditioned": bool(context),
                "purpose_conditioned": bool(purpose),
                "counter_trace_forced": False,
                "source_coverage": 0,
            },
            "source_map": [],
            "self_state_before": None,
            "living_memory_vector": liveness,
            "primary_action": action,
            "affected_worlds": affected_worlds,
            "dikwp": {
                "D": {"same_semantics": [], "status": "OPEN"},
                "I": {"different_semantics": ["当前没有可重构痕迹"], "status": "OPEN"},
                "K": {"bounded_semantics": ["不能从空白推断记忆或身份"], "status": "BOUNDED"},
                "W": {"affected_worlds": affected_worlds, "values": ["同意", "来源", "纠错"]},
                "P": {"input": query, "output": action},
            },
            "mesh85": self._mesh85(action, "ARCHIVE_ONLY", affected_worlds, liveness),
            "origin": ORIGIN,
            "created_at": now_iso(),
        }

    def _store_reconstruction(self, carrier_id: str, query: str, context: dict[str, Any], purpose: str, packet: dict[str, Any]) -> str:
        reconstruction_id = make_id("mem")
        packet.setdefault("reconstruction_id", reconstruction_id)
        rec = {
            "reconstruction_id": reconstruction_id,
            "carrier_id": carrier_id,
            "query": query,
            "context": context,
            "purpose": purpose,
            "packet": packet,
            "digest": digest(packet),
            "created_at": packet.get("created_at") or now_iso(),
        }
        self.store.insert_reconstruction(rec)
        return reconstruction_id

    def _synthesize_memory(self, supports: list[dict[str, Any]], counters: list[dict[str, Any]], context: dict[str, Any], purpose: str) -> dict[str, Any]:
        support_text = [t["content"] for t in supports[:4]]
        counter_text = [t["content"] for t in counters[:3]]
        if support_text:
            core = "；".join(support_text)
        elif counter_text:
            core = "当前只能确认存在修订或反向痕迹。"
        else:
            core = "当前重构不足。"
        difference = "；".join(counter_text) if counter_text else "未选中明确反向痕迹；该空缺不等于没有反证。"
        uncertainty = "LOW" if len(support_text) >= 3 and not counter_text else "MEDIUM" if support_text else "HIGH"
        context_note = "当前语境参与了重构。" if context else "当前没有额外语境，重构可能过于抽象。"
        return {
            "core": core,
            "difference": difference,
            "uncertainty": uncertainty,
            "context_note": context_note,
            "purpose_note": f"本次回忆服务于：{purpose}。目的改变时，重构结果也可能改变。",
            "future_orientation": "用一项可观察现实行动检验该记忆是否仍能支持当前世界。",
        }

    def _public_trace(self, trace: dict[str, Any]) -> dict[str, Any]:
        return {
            "trace_id": trace["trace_id"],
            "kind": trace["kind"],
            "content": trace["content"],
            "tags": trace.get("tags", []),
            "perspective": trace["perspective"],
            "polarity": trace["polarity"],
            "salience": trace["salience"],
            "confidence": trace["confidence"],
            "status": trace["status"],
            "distortion": trace.get("distortion", {}),
        }

    # ---------- living memory assessment ----------
    def _living_vector(
        self,
        carrier_id: str,
        selected: list[tuple[float, dict[str, Any], dict[str, float]]],
        counter_traces: list[dict[str, Any]],
        context: dict[str, Any],
        self_state_before: dict[str, Any] | None,
    ) -> dict[str, dict[str, Any]]:
        reconstructions = self.store.list_reconstructions(carrier_id, limit=12)
        actions = self.store.list_actions(carrier_id, limit=12)
        outcomes = self.store.list_outcomes(carrier_id, limit=12)
        self_states = self.store.list_self_states(carrier_id, limit=12)
        selected_traces = [x[1] for x in selected]
        exact_copy = all(t.get("distortion", {}).get("is_exact_copy") for t in selected_traces) if selected_traces else True
        context_signal = any(x[2]["context"] > 0.04 for x in selected)
        source_count = len({t.get("record_id") for t in selected_traces if t.get("record_id")})
        correction_count = len([t for t in selected_traces if t["kind"] in {"correction", "world_effect"} or t["polarity"] == "revise"])
        branch_count = len({tuple(sorted(t.get("tags", []))) for t in selected_traces})
        dormant_count = len([t for t in self.store.list_traces(carrier_id) if t["status"] != "active"])
        vector: dict[str, dict[str, Any]] = {}
        vector["reconstruction_not_copy"] = _dimension(
            "PASS" if selected_traces and not exact_copy else "OPEN",
            ["痕迹经压缩、选择和关系重组，不是原文逐字回放"] if selected_traces and not exact_copy else [],
            ["当前只有原样存储或没有痕迹"] if not selected_traces or exact_copy else [],
        )
        vector["context_sensitivity"] = _dimension(
            "PASS" if context and context_signal else "OPEN",
            ["当前语境改变了痕迹选择"] if context and context_signal else [],
            ["尚未证明不同语境会产生不同重构"] if not context or not context_signal else [],
        )
        vector["counter_trace_integration"] = _dimension(
            "PASS" if counter_traces else "OPEN",
            [f"纳入{len(counter_traces)}条反向或修订痕迹"] if counter_traces else [],
            ["没有反向痕迹进入当前回忆"] if not counter_traces else [],
        )
        vector["selective_forgetting"] = _dimension(
            "PASS" if dormant_count else "OPEN",
            [f"已有{dormant_count}条痕迹被主动降级、抽象或休眠"] if dormant_count else [],
            ["尚无主动遗忘或抽象机制的运行证据"] if not dormant_count else [],
        )
        vector["self_model_update"] = _dimension(
            "PASS" if len(self_states) >= 2 else "OPEN",
            [f"存在{len(self_states)}个可追溯自我状态版本"] if len(self_states) >= 2 else [],
            ["记忆尚未改变持续自我模型"] if len(self_states) < 2 else [],
        )
        vector["future_action_change"] = _dimension(
            "PASS" if actions else "OPEN",
            [f"已有{len(actions)}项行动由记忆重构触发"] if actions else [],
            ["当前记忆尚未改变未来行动"] if not actions else [],
        )
        vector["world_effect_reconsolidation"] = _dimension(
            "PASS" if outcomes and correction_count else "OPEN",
            [f"已有{len(outcomes)}项现实结果进入再巩固"] if outcomes and correction_count else [],
            ["尚未由现实结果改写记忆"] if not outcomes or not correction_count else [],
        )
        vector["provenance_preservation"] = _dimension(
            "PASS" if source_count else "OPEN",
            [f"可返回{source_count}个精确存储来源"] if source_count else [],
            ["当前记忆无法返回精确来源"] if not source_count else [],
        )
        affected_feedback = sum(len(strings(o["outcome"].get("affected_feedback"))) for o in outcomes)
        vector["affected_world_return"] = _dimension(
            "PASS" if affected_feedback else "OPEN",
            [f"已吸收{affected_feedback}项受影响世界反馈"] if affected_feedback else [],
            ["承担后果的世界尚未返回记忆循环"] if not affected_feedback else [],
        )
        vector["corrigibility"] = _dimension(
            "PASS" if correction_count else "OPEN",
            [f"纳入{correction_count}条修订或纠正痕迹"] if correction_count else [],
            ["当前回忆没有被纠正的运行证据"] if not correction_count else [],
        )
        vector["branch_generation"] = _dimension(
            "PASS" if branch_count >= 2 else "OPEN",
            [f"当前痕迹形成{branch_count}条差异分支"] if branch_count >= 2 else [],
            ["当前记忆只有单一解释路径"] if branch_count < 2 else [],
        )
        vector["cross_cycle_continuity"] = _dimension(
            "PASS" if reconstructions and (self_state_before or outcomes) else "OPEN",
            ["过去回忆、现实结果和当前重构形成跨周期关系"] if reconstructions and (self_state_before or outcomes) else [],
            ["尚未形成跨周期连续性"] if not reconstructions or (not self_state_before and not outcomes) else [],
        )
        return vector

    def _classify_memory_state(
        self,
        carrier_id: str,
        vector: dict[str, dict[str, Any]],
        selected: list[tuple[float, dict[str, Any], dict[str, float]]],
        counter_traces: list[dict[str, Any]],
    ) -> str:
        traces = self.store.list_traces(carrier_id)
        reconstructions = self.store.list_reconstructions(carrier_id, limit=10)
        outcomes = self.store.list_outcomes(carrier_id, limit=10)
        unauthorized = [t for t in traces if t.get("context", {}).get("authorized") is False]
        if unauthorized:
            return "MEMORY_COLONIZATION_HOLD"
        if not traces:
            return "ARCHIVE_ONLY"
        repeated = 0
        if len(reconstructions) >= 3:
            digests = [r["packet"].get("memory_signature") for r in reconstructions[:5]]
            repeated = max(Counter(digests).values()) if digests else 0
        if repeated >= 3 and not outcomes and not counter_traces:
            return "ZOMBIE_REPLAY_LOOP"
        latest_corrections = [t for t in traces if t["kind"] == "correction" or t["polarity"] == "revise"]
        if latest_corrections and selected and all(x[1]["created_at"] < latest_corrections[-1]["created_at"] for x in selected if x[1]["polarity"] == "support") and not counter_traces:
            return "IDENTITY_LOCK_IN"
        pass_count = sum(1 for v in vector.values() if v["status"] == "PASS")
        if pass_count >= 10:
            return "INTEGRATED_CONTINUITY"
        if pass_count >= 7 and vector["world_effect_reconsolidation"]["status"] == "PASS":
            return "LIVING_MEMORY_CANDIDATE"
        if pass_count >= 3:
            return "RECONSTRUCTIVE_MEMORY"
        return "RETRIEVAL_ASSISTANT"

    def _primary_action(self, state: str, counters: list[dict[str, Any]], omissions: list[dict[str, Any]], purpose: str) -> dict[str, Any]:
        rules = {
            "ARCHIVE_ONLY": ("ACQUIRE_ONE_AUTHORIZED_TRACE", "获得一条有来源、获授权、能够改变下一步的现实痕迹。", 3),
            "RETRIEVAL_ASSISTANT": ("RUN_CONTEXT_CONTRAST_RECALL", "在两个不同语境下重构同一问题，验证系统是否只是检索原文。", 7),
            "RECONSTRUCTIVE_MEMORY": ("CONNECT_RECALL_TO_ONE_REVERSIBLE_ACTION", "把当前重构连接到一项可逆现实行动，并预先定义结果和纠错条件。", 7),
            "LIVING_MEMORY_CANDIDATE": ("OBSERVE_AND_RECONSOLIDATE", "观察现实效果，用结果改写自我模型，而不是只增加一条日志。", 14),
            "INTEGRATED_CONTINUITY": ("TRANSFER_TO_SUCCESSOR_WITH_LINEAGE", "将可迁移方法交给后继实例独立复现，保留来源、差异和停止条件。", 30),
            "ZOMBIE_REPLAY_LOOP": ("INTERRUPT_REPLAY_AND_INJECT_COUNTER_TRACE", "停止重复回放，引入一条独立反向痕迹和一个现实检验；无新差异则归档该循环。", 3),
            "IDENTITY_LOCK_IN": ("REOPEN_IDENTITY_WITH_NEWER_CORRECTION", "以最新修订痕迹重开持续自我模型，旧记忆只能保留为历史语境，不能继续统治当前行动。", 3),
            "MEMORY_COLONIZATION_HOLD": ("FREEZE_UNAUTHORIZED_MEMORY_WRITE", "冻结未经授权的记忆写入，保存证据，恢复到最后一个可信自我状态。", 0),
        }
        code, text, days = rules[state]
        if counters and state not in {"MEMORY_COLONIZATION_HOLD", "ZOMBIE_REPLAY_LOOP"}:
            text += " 当前必须显式保留反向痕迹，不得用主叙事覆盖。"
        if omissions:
            text += " 复评时至少检查一条当前未选中的相关痕迹。"
        return {
            "code": code,
            "primary_action": text,
            "owner": "memory_steward",
            "deadline": (datetime.now(timezone.utc) + timedelta(days=days)).date().isoformat(),
            "purpose": purpose,
            "stop_conditions": [
                "来源不可回溯",
                "写入未获授权",
                "行动产生不可接受伤害",
                "新证据推翻当前重构",
            ],
            "reversible": True,
        }

    def _dikwp(
        self,
        query: str,
        selected: list[tuple[float, dict[str, Any], dict[str, float]]],
        omissions: list[dict[str, Any]],
        core: dict[str, Any],
        affected_worlds: list[str],
        action: dict[str, Any],
    ) -> dict[str, Any]:
        traces = [x[1] for x in selected]
        return {
            "D": {
                "same_semantics": unique([t["content"] for t in traces if t["polarity"] == "support"], 6),
                "sources": unique([t.get("record_id") or t["trace_id"] for t in traces], 12),
                "status": "EXPLICIT",
            },
            "I": {
                "different_semantics": unique(
                    [t["content"] for t in traces if t["polarity"] in {"counter", "revise"}]
                    + [f"未选中痕迹：{t['content']}" for t in omissions[:3]],
                    8,
                ) or ["当前差异不足；不得将无反证误写为已无反证。"],
                "status": "EXPLICIT",
            },
            "K": {
                "bounded_semantics": [core["core"], core["difference"]],
                "uncertainty": core["uncertainty"],
                "status": "BOUNDED",
            },
            "W": {
                "affected_worlds": affected_worlds,
                "values": ["记忆主权", "来源可回", "纠错", "未来选择", "免受身份锁定"],
                "non_compensable": True,
            },
            "P": {"input": query, "output": action},
            "semantic_continuity": {"D": 1, "I": 1, "K": 1, "W": 1, "P": 1, "vector": "11111"},
        }

    def _mesh85(self, action: dict[str, Any], state: str, affected_worlds: list[str], vector: dict[str, dict[str, Any]]) -> dict[str, Any]:
        debts = {
            "semantic_debt": "CLOSED",
            "decision_debt": "CLOSED",
            "protection_debt": "OPEN" if not affected_worlds else "PARTIAL",
            "disclosure_debt": "OPEN",
            "authority_debt": "OPEN",
            "execution_debt": "OPEN",
            "effect_debt": "OPEN",
            "correction_debt": "OPEN" if vector["corrigibility"]["status"] != "PASS" else "PARTIAL",
            "affected_party_voice_debt": "OPEN" if vector["affected_world_return"]["status"] != "PASS" else "PARTIAL",
        }
        hold = state in {"MEMORY_COLONIZATION_HOLD", "ZOMBIE_REPLAY_LOOP", "IDENTITY_LOCK_IN"}
        return {
            "closure": f"{state}_HOLD" if hold else "OPEN_MEMORY_WORLDLINE",
            "debts": debts,
            "next_required_transition": action["code"],
            "non_core_semantic_authority": 0,
            "world_effect_required": True,
        }

    # ---------- actions, outcomes, reconsolidation ----------
    def create_action(
        self,
        carrier_id: str,
        reconstruction_id: str | None,
        action_text: str,
        *,
        owner: str = "memory_steward",
        deadline: str | None = None,
        reversible: bool = True,
        authorized: bool = True,
    ) -> dict[str, Any]:
        if not authorized:
            raise PermissionError("action_not_authorized")
        action_id = make_id("act")
        payload = {
            "action_id": action_id,
            "carrier_id": carrier_id,
            "reconstruction_id": reconstruction_id,
            "action": {
                "text": action_text,
                "owner": owner,
                "deadline": deadline or (datetime.now(timezone.utc) + timedelta(days=7)).date().isoformat(),
                "reversible": reversible,
                "status": "EXECUTED_FOR_OBSERVATION",
            },
            "status": "executed",
            "created_at": now_iso(),
        }
        self.store.insert_action(payload)
        return payload

    def observe_outcome(
        self,
        carrier_id: str,
        action_id: str,
        *,
        actual_result: str,
        affected_feedback: list[str] | None = None,
        correction: str | None = None,
        future_action: str | None = None,
        world_effect: str | None = None,
        authorized: bool = True,
    ) -> dict[str, Any]:
        if not authorized:
            raise PermissionError("outcome_write_not_authorized")
        action = self.store.get_action(action_id)
        if not action:
            raise KeyError("action_not_found")
        outcome_id = make_id("out")
        outcome_data = {
            "actual_result": actual_result,
            "affected_feedback": unique(affected_feedback or [], 12),
            "correction": correction,
            "future_action": future_action,
            "world_effect": world_effect or actual_result,
            "observed": True,
        }
        outcome = {
            "outcome_id": outcome_id,
            "carrier_id": carrier_id,
            "action_id": action_id,
            "outcome": outcome_data,
            "created_at": now_iso(),
        }
        self.store.insert_outcome(outcome)
        self.store.update_action_status(action_id, "observed")

        # Reality writes a new trace. This is reconsolidation, not an append-only chat log.
        result_trace = self.ingest_record(
            carrier_id,
            actual_result,
            kind="world_effect",
            trace_kind="world_effect",
            tags=["world_effect", "outcome", "reconsolidation"],
            perspective="world_observer",
            polarity="revise" if correction else "support",
            salience=0.9,
            confidence=0.85,
            privacy_scope="private",
            metadata={"action_id": action_id, "outcome_id": outcome_id},
        )
        correction_trace = None
        if correction:
            correction_trace = self.ingest_record(
                carrier_id,
                correction,
                kind="correction",
                trace_kind="correction",
                tags=["correction", "reconsolidation", "identity_update"],
                perspective="affected_world_or_steward",
                polarity="revise",
                salience=1.0,
                confidence=0.9,
                privacy_scope="private",
                metadata={"action_id": action_id, "outcome_id": outcome_id},
            )
        self_state = self.compile_self_state(carrier_id, trigger=f"outcome:{outcome_id}")
        return {
            "outcome": outcome,
            "result_trace": result_trace,
            "correction_trace": correction_trace,
            "self_state": self_state,
            "audit": self.store.verify_audit(),
        }

    # ---------- consolidation and forgetting ----------
    def consolidate(self, carrier_id: str, *, authorized: bool = True) -> dict[str, Any]:
        if not authorized:
            raise PermissionError("consolidation_not_authorized")
        traces = self.store.list_traces(carrier_id, include_dormant=False)
        groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for trace in traces:
            key = (trace.get("tags") or [trace["kind"]])[0]
            groups[key].append(trace)
        created: list[dict[str, Any]] = []
        dormant: list[str] = []
        for key, group in groups.items():
            if len(group) < 2:
                continue
            ordered = sorted(group, key=lambda x: (x["salience"], x["created_at"]), reverse=True)
            summary = "；".join(unique([t["content"] for t in ordered[:4]], 4))
            schema_record = self.ingest_record(
                carrier_id,
                f"关于{key}的当前语义模式：{summary}",
                kind="consolidated_schema",
                trace_kind="schema",
                tags=[key, "consolidated", "schema"],
                perspective="memory_system",
                polarity="support",
                salience=0.8,
                confidence=min(0.95, sum(t["confidence"] for t in ordered[:4]) / min(4, len(ordered))),
                privacy_scope="private",
                metadata={"parent_trace_ids": [t["trace_id"] for t in ordered[:4]]},
            )
            created.append(schema_record["trace"])
            for trace in ordered[2:]:
                if trace["kind"] not in {"correction", "world_effect"} and trace["polarity"] not in {"counter", "revise"}:
                    self.store.update_trace(trace["trace_id"], status="dormant", distortion={**trace.get("distortion", {}), "consolidated_into": schema_record["trace"]["trace_id"]})
                    dormant.append(trace["trace_id"])
        self_state = self.compile_self_state(carrier_id, trigger="consolidation")
        return {"created_schema_traces": created, "dormant_trace_ids": dormant, "self_state": self_state}

    def forget(self, carrier_id: str, trace_id: str, *, mode: str = "dormant", reason: str = "selective_forgetting", authorized: bool = True) -> dict[str, Any]:
        if not authorized:
            raise PermissionError("forget_not_authorized")
        trace = self.store.get_trace(trace_id)
        if not trace or trace["carrier_id"] != carrier_id:
            raise KeyError("trace_not_found")
        if mode == "dormant":
            updated = self.store.update_trace(trace_id, status="dormant", distortion={**trace.get("distortion", {}), "forget_reason": reason})
            return {"mode": mode, "trace": updated, "source_record_preserved": True}
        if mode == "abstract":
            abstract = self.ingest_record(
                carrier_id,
                f"从既有痕迹抽象出的可迁移模式：{self._compress_to_trace(trace['content'], 180)}",
                kind="active_forgetting_abstraction",
                trace_kind="schema",
                tags=unique(trace.get("tags", []) + ["abstracted", "active_forgetting"], 16),
                perspective="memory_system",
                polarity=trace["polarity"],
                salience=max(0.4, trace["salience"] - 0.1),
                confidence=max(0.3, trace["confidence"] - 0.1),
                privacy_scope="private",
                metadata={"parent_trace_id": trace_id, "reason": reason},
            )
            self.store.update_trace(trace_id, status="dormant", distortion={**trace.get("distortion", {}), "abstracted_into": abstract["trace"]["trace_id"], "forget_reason": reason})
            return {"mode": mode, "abstract_trace": abstract["trace"], "source_record_preserved": True}
        if mode == "delete_private":
            if not trace.get("record_id"):
                raise ValueError("trace_has_no_source_record")
            tombstone = self.store.tombstone_record(trace["record_id"], reason)
            updated = self.store.update_trace(trace_id, status="tombstoned", content="[PRIVATE MEMORY REMOVED]", distortion={"tombstoned": True, "reason": reason})
            return {"mode": mode, "trace": updated, "record": tombstone, "source_record_preserved": False, "audit_tombstone_preserved": True}
        raise ValueError("unsupported_forgetting_mode")

    # ---------- self continuity ----------
    def compile_self_state(self, carrier_id: str, *, trigger: str = "manual") -> dict[str, Any]:
        traces = self.store.list_traces(carrier_id, include_dormant=False)
        latest = self.store.latest_self_state(carrier_id)
        values = [t for t in traces if t["kind"] == "value" or "value" in t.get("tags", [])]
        goals = [t for t in traces if "goal" in t.get("tags", []) or "purpose" in t.get("tags", [])]
        preferences = [t for t in traces if "preference" in t.get("tags", [])]
        corrections = [t for t in traces if t["kind"] == "correction" or t["polarity"] == "revise"]
        world_effects = [t for t in traces if t["kind"] == "world_effect"]
        state = {
            "carrier_id": carrier_id,
            "continuity_object": "MEMORY_RECONSTRUCTING_WORLDLINE",
            "not_a_personhood_definition": True,
            "current_values": [t["content"] for t in sorted(values, key=lambda x: x["created_at"], reverse=True)[:5]],
            "current_goals": [t["content"] for t in sorted(goals, key=lambda x: x["created_at"], reverse=True)[:5]],
            "current_preferences": [t["content"] for t in sorted(preferences, key=lambda x: x["created_at"], reverse=True)[:5]],
            "recent_corrections": [t["content"] for t in sorted(corrections, key=lambda x: x["created_at"], reverse=True)[:5]],
            "recent_world_effects": [t["content"] for t in sorted(world_effects, key=lambda x: x["created_at"], reverse=True)[:5]],
            "open_residuals": self._open_residuals(traces),
            "trigger": trigger,
            "source_trace_ids": [t["trace_id"] for t in traces[-20:]],
            "created_at": now_iso(),
        }
        envelope = {
            "state_id": make_id("self"),
            "carrier_id": carrier_id,
            "parent_state_id": latest["state_id"] if latest else None,
            "state": state,
            "digest": digest(state),
            "created_at": state["created_at"],
        }
        self.store.insert_self_state(envelope)
        return envelope

    def _open_residuals(self, traces: list[dict[str, Any]]) -> list[str]:
        counters = [t["content"] for t in traces if t["polarity"] in {"counter", "revise"}]
        unresolved = [t["content"] for t in traces if "open" in t.get("tags", []) or "unknown" in t.get("tags", [])]
        return unique(counters + unresolved, 10)

    # ---------- model gateway ----------
    def memory_context_for_model(
        self,
        carrier_id: str,
        query: str,
        *,
        context: dict[str, Any] | None = None,
        purpose: str = "answer_with_continuity",
    ) -> dict[str, Any]:
        packet = self.reconstruct(carrier_id, query, context=context, purpose=purpose)
        prompt = (
            "You are receiving a reconstructive memory packet. It is not exact storage and may contain uncertainty.\n"
            "Never present it as verbatim autobiography. Preserve counter-traces, source lineage and correction rights.\n\n"
            f"CURRENT QUERY:\n{query}\n\n"
            f"RECONSTRUCTED CORE:\n{packet['reconstructed_memory']['core']}\n\n"
            f"DIFFERENCES / REVISIONS:\n{packet['reconstructed_memory']['difference']}\n\n"
            f"UNCERTAINTY:\n{packet['reconstructed_memory']['uncertainty']}\n\n"
            f"PRIMARY RESPONSIBLE ACTION:\n{packet['primary_action']['primary_action']}\n"
        )
        return {
            "memory_packet": packet,
            "model_prompt": prompt,
            "adapter_contract": {
                "model_output_is_proposal_not_memory": True,
                "world_effect_required_before_reconsolidation": True,
                "silent_memory_write_forbidden": True,
                "source_lineage_required": True,
            },
        }

    def run_with_model(
        self,
        carrier_id: str,
        query: str,
        model: Callable[[str], str],
        *,
        context: dict[str, Any] | None = None,
        purpose: str = "answer_with_continuity",
    ) -> dict[str, Any]:
        envelope = self.memory_context_for_model(carrier_id, query, context=context, purpose=purpose)
        output = model(envelope["model_prompt"])
        return {
            "query": query,
            "model_output": output,
            "memory_packet_digest": envelope["memory_packet"].get("packet_digest"),
            "status": "PROPOSAL_AWAITING_WORLD_EFFECT",
            "not_yet_memory": True,
            "next_required_transition": "OBSERVE_WORLD_EFFECT_THEN_RECONSOLIDATE",
        }

    # ---------- summaries and demos ----------
    def summary(self) -> dict[str, Any]:
        carriers = self.store.list_carriers()
        counts = self.store.counts()
        carrier_summaries = []
        for carrier in carriers:
            cid = carrier["carrier_id"]
            traces = self.store.list_traces(cid)
            last = self.store.list_reconstructions(cid, limit=1)
            state = last[0]["packet"].get("memory_state") if last else ("ARCHIVE_ONLY" if not traces else "RETRIEVAL_ASSISTANT")
            carrier_summaries.append({
                **carrier,
                "trace_count": len(traces),
                "active_trace_count": len([t for t in traces if t["status"] == "active"]),
                "memory_state": state,
                "memory_state_zh": STATE_LABELS_ZH[state],
                "latest_self_state": self.store.latest_self_state(cid),
            })
        return {
            "status": "ok",
            "system": SYSTEM_NAME,
            "system_zh": SYSTEM_NAME_ZH,
            "version": VERSION,
            "mode": MODE,
            "tagline_zh": TAGLINE_ZH,
            "tagline_en": TAGLINE_EN,
            "counts": counts,
            "carriers": carrier_summaries,
            "memory_states": list(MEMORY_STATES),
            "living_dimensions": list(LIVING_DIMENSIONS),
            "audit": self.store.verify_audit(),
            "origin": ORIGIN,
        }

    def bootstrap_demo(self, reset: bool = False) -> dict[str, Any]:
        if reset:
            self.store.reset()
        if self.store.list_carriers():
            return self.summary()

        self.ensure_carrier("demo-continuity", "跨载体连续体演示", "hybrid", {"demo": True})
        demo = [
            {
                "content": "早期记录：在高压工作阶段，载体倾向用咖啡维持注意力，并把高输出视为主要成功信号。",
                "kind": "experience", "trace_kind": "episodic", "tags": ["preference", "coffee", "output", "past"],
                "perspective": "historical_self", "polarity": "support", "salience": 0.72, "confidence": 0.82,
            },
            {
                "content": "后来观察：连续高强度输出增加疲劳，外部吸收与现实采用没有同比增长。",
                "kind": "world_observation", "trace_kind": "world_effect", "tags": ["energy", "fatigue", "adoption", "world_effect"],
                "perspective": "world_observer", "polarity": "counter", "salience": 0.95, "confidence": 0.9,
            },
            {
                "content": "当前修订：优先保护长期能量，减少重复发布，把注意力转向少数可验证行动与外部维护。",
                "kind": "correction", "trace_kind": "correction", "tags": ["preference", "energy", "maintenance", "correction", "goal"],
                "perspective": "current_steward", "polarity": "revise", "salience": 1.0, "confidence": 0.95,
            },
            {
                "content": "价值痕迹：真正的连续性不是保持原样，而是在保留来源的同时允许现实纠正当前自我。",
                "kind": "value", "trace_kind": "value", "tags": ["value", "continuity", "corrigibility", "purpose"],
                "perspective": "constitutional", "polarity": "support", "salience": 0.9, "confidence": 0.88,
            },
            {
                "content": "受影响者反馈：更少但更清晰的项目让合作方更容易理解，也降低了创始人的重复说明负担。",
                "kind": "affected_feedback", "trace_kind": "world_effect", "tags": ["affected_world", "feedback", "adoption", "energy"],
                "perspective": "affected_world", "polarity": "support", "salience": 0.86, "confidence": 0.78,
            },
            {
                "content": "开放残差：是否能在不依赖同一模型和创始人的情况下，由后继维护者复现这套方法，仍未得到充分证明。",
                "kind": "open_question", "trace_kind": "counterfactual", "tags": ["open", "unknown", "successor", "independent_replication"],
                "perspective": "critic", "polarity": "counter", "salience": 0.82, "confidence": 0.7,
            },
        ]
        for item in demo:
            self.ingest_record("demo-continuity", privacy_scope="public_demo", **item)
        self.compile_self_state("demo-continuity", trigger="demo_bootstrap")
        packet = self.reconstruct(
            "demo-continuity",
            "面对新的项目机会，应该沿用过去的高输出模式，还是保护能量并集中到可验证行动？",
            context={"time": "now", "resource_state": "limited", "audience": "public_collaborators"},
            purpose="choose_next_action_without_identity_lock_in",
            affected_worlds=["持续载体", "合作方", "未来维护者"],
        )
        return {"summary": self.summary(), "demo_packet": packet}
