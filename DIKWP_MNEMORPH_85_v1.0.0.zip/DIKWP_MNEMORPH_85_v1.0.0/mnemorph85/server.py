from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import os
from pathlib import Path
import re
from typing import Any
from urllib.parse import parse_qs, urlparse

from .core import MemoryEngine, SYSTEM_NAME, SYSTEM_NAME_ZH, VERSION
from .store import MemoryStore

MAX_BODY = 2 * 1024 * 1024


class App:
    def __init__(self, root: Path, db_path: str | Path) -> None:
        self.root = root
        self.store = MemoryStore(db_path)
        self.engine = MemoryEngine(self.store)
        self.engine.bootstrap_demo()


class Handler(BaseHTTPRequestHandler):
    server_version = "MNEMORPH85/1.0"

    @property
    def app(self) -> App:
        return self.server.app  # type: ignore[attr-defined]

    def log_message(self, fmt: str, *args: Any) -> None:
        if os.getenv("MNEMORPH_QUIET") != "1":
            super().log_message(fmt, *args)

    def _headers(self, status: int = 200, content_type: str = "application/json; charset=utf-8", length: int | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'")
        if length is not None:
            self.send_header("Content-Length", str(length))
        self.end_headers()

    def _json(self, payload: Any, status: int = 200) -> None:
        data = json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2).encode("utf-8")
        self._headers(status, length=len(data))
        self.wfile.write(data)

    def _error(self, status: int, message: str, detail: str | None = None) -> None:
        self._json({"error": message, "detail": detail}, status=status)

    def _body_json(self) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ValueError("invalid_content_length")
        if length <= 0 or length > MAX_BODY:
            raise ValueError("body_missing_or_too_large")
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except Exception as exc:
            raise ValueError("invalid_json") from exc
        if not isinstance(payload, dict):
            raise ValueError("json_object_required")
        return payload

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        try:
            if path == "/api/health":
                self._json({
                    "status": "ok",
                    "system": SYSTEM_NAME,
                    "system_zh": SYSTEM_NAME_ZH,
                    "version": VERSION,
                    "runtime": "Python standard library / SQLite / vanilla JavaScript / offline-first",
                    "audit": self.app.store.verify_audit(),
                })
                return
            if path == "/api/summary":
                self._json(self.app.engine.summary())
                return
            if path == "/api/carriers":
                self._json({"carriers": self.app.store.list_carriers()})
                return
            if path == "/api/traces":
                carrier_id = (query.get("carrier_id") or ["demo-continuity"])[0]
                include = (query.get("include_dormant") or ["1"])[0] != "0"
                self._json({"carrier_id": carrier_id, "traces": self.app.store.list_traces(carrier_id, include_dormant=include)})
                return
            if path == "/api/reconstructions":
                carrier_id = (query.get("carrier_id") or ["demo-continuity"])[0]
                self._json({"carrier_id": carrier_id, "reconstructions": self.app.store.list_reconstructions(carrier_id, limit=50)})
                return
            if path == "/api/self-state":
                carrier_id = (query.get("carrier_id") or ["demo-continuity"])[0]
                self._json({"carrier_id": carrier_id, "latest": self.app.store.latest_self_state(carrier_id), "history": self.app.store.list_self_states(carrier_id, 50)})
                return
            if path == "/api/actions":
                carrier_id = (query.get("carrier_id") or ["demo-continuity"])[0]
                self._json({"carrier_id": carrier_id, "actions": self.app.store.list_actions(carrier_id, 50), "outcomes": self.app.store.list_outcomes(carrier_id, 50)})
                return
            if path == "/api/audit/verify":
                self._json(self.app.store.verify_audit())
                return
            if path.startswith("/api/reconstruction/"):
                rid = path.rsplit("/", 1)[-1]
                rec = self.app.store.get_reconstruction(rid)
                if not rec:
                    self._error(404, "reconstruction_not_found")
                else:
                    self._json(rec)
                return
            self._static(path)
        except Exception as exc:
            self._error(500, "internal_error", str(exc))

    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        try:
            payload = self._body_json()
            if path == "/api/demo/reset":
                result = self.app.engine.bootstrap_demo(reset=True)
                self._json(result)
                return
            if path == "/api/carriers":
                carrier = self.app.engine.ensure_carrier(
                    payload["carrier_id"], payload.get("label"), payload.get("carrier_kind", "unknown"), payload.get("metadata")
                )
                self._json(carrier, 201)
                return
            if path == "/api/records":
                result = self.app.engine.ingest_record(
                    payload.get("carrier_id", "demo-continuity"),
                    payload["content"],
                    kind=payload.get("kind", "observation"),
                    trace_kind=payload.get("trace_kind", "episodic"),
                    tags=payload.get("tags"),
                    source_uri=payload.get("source_uri"),
                    source_time=payload.get("source_time"),
                    perspective=payload.get("perspective", "first_party"),
                    polarity=payload.get("polarity", "support"),
                    salience=payload.get("salience", 0.6),
                    confidence=payload.get("confidence", 0.7),
                    privacy_scope=payload.get("privacy_scope", "private"),
                    metadata=payload.get("metadata"),
                    authorized=payload.get("authorized", True),
                )
                self._json(result, 201)
                return
            if path == "/api/reconstruct":
                result = self.app.engine.reconstruct(
                    payload.get("carrier_id", "demo-continuity"),
                    payload["query"],
                    context=payload.get("context"),
                    purpose=payload.get("purpose", "understand_and_act"),
                    affected_worlds=payload.get("affected_worlds"),
                    max_traces=int(payload.get("max_traces", 6)),
                )
                self._json(result, 201)
                return
            if path == "/api/model/context":
                result = self.app.engine.memory_context_for_model(
                    payload.get("carrier_id", "demo-continuity"),
                    payload["query"],
                    context=payload.get("context"),
                    purpose=payload.get("purpose", "answer_with_continuity"),
                )
                self._json(result, 201)
                return
            if path == "/api/consolidate":
                result = self.app.engine.consolidate(payload.get("carrier_id", "demo-continuity"), authorized=payload.get("authorized", True))
                self._json(result, 201)
                return
            if path == "/api/forget":
                result = self.app.engine.forget(
                    payload.get("carrier_id", "demo-continuity"),
                    payload["trace_id"],
                    mode=payload.get("mode", "dormant"),
                    reason=payload.get("reason", "selective_forgetting"),
                    authorized=payload.get("authorized", True),
                )
                self._json(result, 201)
                return
            if path == "/api/self-state":
                result = self.app.engine.compile_self_state(payload.get("carrier_id", "demo-continuity"), trigger=payload.get("trigger", "manual"))
                self._json(result, 201)
                return
            if path == "/api/actions":
                result = self.app.engine.create_action(
                    payload.get("carrier_id", "demo-continuity"),
                    payload.get("reconstruction_id"),
                    payload["action_text"],
                    owner=payload.get("owner", "memory_steward"),
                    deadline=payload.get("deadline"),
                    reversible=payload.get("reversible", True),
                    authorized=payload.get("authorized", True),
                )
                self._json(result, 201)
                return
            m = re.fullmatch(r"/api/actions/([^/]+)/outcome", path)
            if m:
                result = self.app.engine.observe_outcome(
                    payload.get("carrier_id", "demo-continuity"),
                    m.group(1),
                    actual_result=payload["actual_result"],
                    affected_feedback=payload.get("affected_feedback"),
                    correction=payload.get("correction"),
                    future_action=payload.get("future_action"),
                    world_effect=payload.get("world_effect"),
                    authorized=payload.get("authorized", True),
                )
                self._json(result, 201)
                return
            self._error(404, "endpoint_not_found")
        except PermissionError as exc:
            self._error(403, str(exc))
        except KeyError as exc:
            self._error(404, str(exc).strip("'"))
        except ValueError as exc:
            self._error(400, str(exc))
        except Exception as exc:
            self._error(500, "internal_error", str(exc))

    def _static(self, path: str) -> None:
        if path in {"", "/"}:
            path = "/index.html"
        rel = path.lstrip("/")
        target = (self.app.root / rel).resolve()
        if self.app.root.resolve() not in target.parents and target != self.app.root.resolve():
            self._error(403, "forbidden")
            return
        if not target.exists() or not target.is_file():
            self._error(404, "not_found")
            return
        data = target.read_bytes()
        ctype, _ = mimetypes.guess_type(str(target))
        self._headers(200, (ctype or "application/octet-stream") + ("; charset=utf-8" if (ctype or "").startswith(("text/", "application/javascript")) else ""), len(data))
        self.wfile.write(data)


def serve(root: str | Path, db_path: str | Path, host: str = "127.0.0.1", port: int = 8780) -> None:
    root_path = Path(root).resolve()
    httpd = ThreadingHTTPServer((host, port), Handler)
    httpd.app = App(root_path, db_path)  # type: ignore[attr-defined]
    print(f"{SYSTEM_NAME_ZH} running at http://{host}:{port}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
