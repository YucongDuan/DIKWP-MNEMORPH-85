from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
from typing import Any, Iterator


def canonical(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


class MemoryStore:
    """SQLite event store for exact records, reconstructive traces and world effects."""

    def __init__(self, path: str | Path = "var/mnemorph85.db") -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def _init_schema(self) -> None:
        with self.connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS carriers (
                    carrier_id TEXT PRIMARY KEY,
                    label TEXT NOT NULL,
                    carrier_kind TEXT NOT NULL,
                    metadata_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS records (
                    record_id TEXT PRIMARY KEY,
                    carrier_id TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    content TEXT NOT NULL,
                    source_uri TEXT,
                    source_time TEXT,
                    digest TEXT NOT NULL,
                    metadata_json TEXT NOT NULL,
                    privacy_scope TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(carrier_id) REFERENCES carriers(carrier_id)
                );

                CREATE TABLE IF NOT EXISTS traces (
                    trace_id TEXT PRIMARY KEY,
                    carrier_id TEXT NOT NULL,
                    record_id TEXT,
                    parent_trace_id TEXT,
                    kind TEXT NOT NULL,
                    content TEXT NOT NULL,
                    tags_json TEXT NOT NULL,
                    perspective TEXT NOT NULL,
                    polarity TEXT NOT NULL,
                    salience REAL NOT NULL,
                    confidence REAL NOT NULL,
                    status TEXT NOT NULL,
                    context_json TEXT NOT NULL,
                    distortion_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY(carrier_id) REFERENCES carriers(carrier_id),
                    FOREIGN KEY(record_id) REFERENCES records(record_id),
                    FOREIGN KEY(parent_trace_id) REFERENCES traces(trace_id)
                );

                CREATE TABLE IF NOT EXISTS reconstructions (
                    reconstruction_id TEXT PRIMARY KEY,
                    carrier_id TEXT NOT NULL,
                    query TEXT NOT NULL,
                    context_json TEXT NOT NULL,
                    purpose TEXT NOT NULL,
                    packet_json TEXT NOT NULL,
                    digest TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(carrier_id) REFERENCES carriers(carrier_id)
                );

                CREATE TABLE IF NOT EXISTS self_states (
                    state_id TEXT PRIMARY KEY,
                    carrier_id TEXT NOT NULL,
                    parent_state_id TEXT,
                    state_json TEXT NOT NULL,
                    digest TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(carrier_id) REFERENCES carriers(carrier_id),
                    FOREIGN KEY(parent_state_id) REFERENCES self_states(state_id)
                );

                CREATE TABLE IF NOT EXISTS actions (
                    action_id TEXT PRIMARY KEY,
                    carrier_id TEXT NOT NULL,
                    reconstruction_id TEXT,
                    action_json TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(carrier_id) REFERENCES carriers(carrier_id),
                    FOREIGN KEY(reconstruction_id) REFERENCES reconstructions(reconstruction_id)
                );

                CREATE TABLE IF NOT EXISTS outcomes (
                    outcome_id TEXT PRIMARY KEY,
                    carrier_id TEXT NOT NULL,
                    action_id TEXT NOT NULL,
                    outcome_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(carrier_id) REFERENCES carriers(carrier_id),
                    FOREIGN KEY(action_id) REFERENCES actions(action_id)
                );

                CREATE TABLE IF NOT EXISTS audit_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    object_id TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    previous_hash TEXT NOT NULL,
                    event_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                """
            )

    def reset(self) -> None:
        with self.connect() as conn:
            for table in (
                "outcomes",
                "actions",
                "self_states",
                "reconstructions",
                "traces",
                "records",
                "carriers",
                "audit_events",
            ):
                conn.execute(f"DELETE FROM {table}")

    def append_audit(self, event_type: str, object_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        created = now_iso()
        with self.connect() as conn:
            row = conn.execute(
                "SELECT event_hash FROM audit_events ORDER BY event_id DESC LIMIT 1"
            ).fetchone()
            prev = row["event_hash"] if row else "0" * 64
            envelope = {
                "event_type": event_type,
                "object_id": object_id,
                "payload": payload,
                "previous_hash": prev,
                "created_at": created,
            }
            event_hash = sha256_text(canonical(envelope))
            conn.execute(
                "INSERT INTO audit_events(event_type, object_id, payload_json, previous_hash, event_hash, created_at) VALUES(?,?,?,?,?,?)",
                (event_type, object_id, canonical(payload), prev, event_hash, created),
            )
        return {**envelope, "event_hash": event_hash}

    def verify_audit(self) -> dict[str, Any]:
        errors: list[dict[str, Any]] = []
        prev = "0" * 64
        count = 0
        head = prev
        with self.connect() as conn:
            rows = conn.execute("SELECT * FROM audit_events ORDER BY event_id").fetchall()
        for row in rows:
            count += 1
            payload = json.loads(row["payload_json"])
            envelope = {
                "event_type": row["event_type"],
                "object_id": row["object_id"],
                "payload": payload,
                "previous_hash": row["previous_hash"],
                "created_at": row["created_at"],
            }
            expected = sha256_text(canonical(envelope))
            if row["previous_hash"] != prev:
                errors.append({"event_id": row["event_id"], "error": "previous_hash_mismatch"})
            if row["event_hash"] != expected:
                errors.append({"event_id": row["event_id"], "error": "event_hash_mismatch"})
            prev = row["event_hash"]
            head = prev
        return {"valid": not errors, "event_count": count, "errors": errors, "head_hash": head}

    def upsert_carrier(self, carrier: dict[str, Any]) -> None:
        created = carrier.get("created_at") or now_iso()
        updated = now_iso()
        with self.connect() as conn:
            conn.execute(
                """
                INSERT INTO carriers(carrier_id,label,carrier_kind,metadata_json,created_at,updated_at)
                VALUES(?,?,?,?,?,?)
                ON CONFLICT(carrier_id) DO UPDATE SET
                    label=excluded.label,
                    carrier_kind=excluded.carrier_kind,
                    metadata_json=excluded.metadata_json,
                    updated_at=excluded.updated_at
                """,
                (
                    carrier["carrier_id"],
                    carrier["label"],
                    carrier.get("carrier_kind", "unknown"),
                    canonical(carrier.get("metadata", {})),
                    created,
                    updated,
                ),
            )
        self.append_audit("carrier.upsert", carrier["carrier_id"], carrier)

    def list_carriers(self) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute("SELECT * FROM carriers ORDER BY created_at").fetchall()
        return [
            {
                "carrier_id": r["carrier_id"],
                "label": r["label"],
                "carrier_kind": r["carrier_kind"],
                "metadata": json.loads(r["metadata_json"]),
                "created_at": r["created_at"],
                "updated_at": r["updated_at"],
            }
            for r in rows
        ]

    def insert_record(self, record: dict[str, Any]) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO records(record_id,carrier_id,kind,content,source_uri,source_time,digest,metadata_json,privacy_scope,created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (
                    record["record_id"], record["carrier_id"], record["kind"], record["content"],
                    record.get("source_uri"), record.get("source_time"), record["digest"],
                    canonical(record.get("metadata", {})), record.get("privacy_scope", "private"), record["created_at"],
                ),
            )
        self.append_audit("record.insert", record["record_id"], {k: v for k, v in record.items() if k != "content"} | {"content_digest": record["digest"]})

    def get_record(self, record_id: str) -> dict[str, Any] | None:
        with self.connect() as conn:
            r = conn.execute("SELECT * FROM records WHERE record_id=?", (record_id,)).fetchone()
        if not r:
            return None
        return {
            "record_id": r["record_id"], "carrier_id": r["carrier_id"], "kind": r["kind"],
            "content": r["content"], "source_uri": r["source_uri"], "source_time": r["source_time"],
            "digest": r["digest"], "metadata": json.loads(r["metadata_json"]),
            "privacy_scope": r["privacy_scope"], "created_at": r["created_at"],
        }

    def list_records(self, carrier_id: str | None = None) -> list[dict[str, Any]]:
        sql = "SELECT * FROM records"
        params: tuple[Any, ...] = ()
        if carrier_id:
            sql += " WHERE carrier_id=?"
            params = (carrier_id,)
        sql += " ORDER BY created_at"
        with self.connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [
            {
                "record_id": r["record_id"], "carrier_id": r["carrier_id"], "kind": r["kind"],
                "content": r["content"], "source_uri": r["source_uri"], "source_time": r["source_time"],
                "digest": r["digest"], "metadata": json.loads(r["metadata_json"]),
                "privacy_scope": r["privacy_scope"], "created_at": r["created_at"],
            }
            for r in rows
        ]

    def tombstone_record(self, record_id: str, reason: str) -> dict[str, Any] | None:
        record = self.get_record(record_id)
        if not record:
            return None
        original_digest = record["digest"]
        tombstone = f"[TOMBSTONED:{reason}]"
        new_digest = sha256_text(tombstone)
        with self.connect() as conn:
            conn.execute(
                "UPDATE records SET content=?, digest=?, metadata_json=? WHERE record_id=?",
                (
                    tombstone,
                    new_digest,
                    canonical({**record.get("metadata", {}), "tombstoned": True, "original_digest": original_digest, "reason": reason}),
                    record_id,
                ),
            )
        self.append_audit("record.tombstone", record_id, {"reason": reason, "original_digest": original_digest, "new_digest": new_digest})
        return self.get_record(record_id)

    def insert_trace(self, trace: dict[str, Any]) -> None:
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO traces(trace_id,carrier_id,record_id,parent_trace_id,kind,content,tags_json,perspective,polarity,salience,confidence,status,context_json,distortion_json,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    trace["trace_id"], trace["carrier_id"], trace.get("record_id"), trace.get("parent_trace_id"),
                    trace["kind"], trace["content"], canonical(trace.get("tags", [])), trace.get("perspective", "unknown"),
                    trace.get("polarity", "support"), float(trace.get("salience", 0.5)), float(trace.get("confidence", 0.5)),
                    trace.get("status", "active"), canonical(trace.get("context", {})), canonical(trace.get("distortion", {})),
                    trace["created_at"], trace.get("updated_at", trace["created_at"]),
                ),
            )
        self.append_audit("trace.insert", trace["trace_id"], {k: v for k, v in trace.items() if k != "content"} | {"content_digest": sha256_text(trace["content"])})

    def update_trace(self, trace_id: str, **changes: Any) -> dict[str, Any] | None:
        trace = self.get_trace(trace_id)
        if not trace:
            return None
        merged = {**trace, **changes, "updated_at": now_iso()}
        with self.connect() as conn:
            conn.execute(
                """UPDATE traces SET kind=?,content=?,tags_json=?,perspective=?,polarity=?,salience=?,confidence=?,status=?,context_json=?,distortion_json=?,updated_at=? WHERE trace_id=?""",
                (
                    merged["kind"], merged["content"], canonical(merged.get("tags", [])), merged.get("perspective", "unknown"),
                    merged.get("polarity", "support"), float(merged.get("salience", 0.5)), float(merged.get("confidence", 0.5)),
                    merged.get("status", "active"), canonical(merged.get("context", {})), canonical(merged.get("distortion", {})),
                    merged["updated_at"], trace_id,
                ),
            )
        self.append_audit("trace.update", trace_id, {"changes": changes})
        return self.get_trace(trace_id)

    def get_trace(self, trace_id: str) -> dict[str, Any] | None:
        with self.connect() as conn:
            r = conn.execute("SELECT * FROM traces WHERE trace_id=?", (trace_id,)).fetchone()
        return self._row_trace(r) if r else None

    def _row_trace(self, r: sqlite3.Row) -> dict[str, Any]:
        return {
            "trace_id": r["trace_id"], "carrier_id": r["carrier_id"], "record_id": r["record_id"],
            "parent_trace_id": r["parent_trace_id"], "kind": r["kind"], "content": r["content"],
            "tags": json.loads(r["tags_json"]), "perspective": r["perspective"], "polarity": r["polarity"],
            "salience": r["salience"], "confidence": r["confidence"], "status": r["status"],
            "context": json.loads(r["context_json"]), "distortion": json.loads(r["distortion_json"]),
            "created_at": r["created_at"], "updated_at": r["updated_at"],
        }

    def list_traces(self, carrier_id: str, include_dormant: bool = True) -> list[dict[str, Any]]:
        sql = "SELECT * FROM traces WHERE carrier_id=?"
        params: list[Any] = [carrier_id]
        if not include_dormant:
            sql += " AND status='active'"
        sql += " ORDER BY created_at"
        with self.connect() as conn:
            rows = conn.execute(sql, tuple(params)).fetchall()
        return [self._row_trace(r) for r in rows]

    def insert_reconstruction(self, reconstruction: dict[str, Any]) -> None:
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO reconstructions(reconstruction_id,carrier_id,query,context_json,purpose,packet_json,digest,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (
                    reconstruction["reconstruction_id"], reconstruction["carrier_id"], reconstruction["query"],
                    canonical(reconstruction.get("context", {})), reconstruction.get("purpose", ""),
                    canonical(reconstruction["packet"]), reconstruction["digest"], reconstruction["created_at"],
                ),
            )
        self.append_audit("reconstruction.insert", reconstruction["reconstruction_id"], {"carrier_id": reconstruction["carrier_id"], "digest": reconstruction["digest"], "query": reconstruction["query"]})

    def get_reconstruction(self, reconstruction_id: str) -> dict[str, Any] | None:
        with self.connect() as conn:
            r = conn.execute("SELECT * FROM reconstructions WHERE reconstruction_id=?", (reconstruction_id,)).fetchone()
        if not r:
            return None
        return {
            "reconstruction_id": r["reconstruction_id"], "carrier_id": r["carrier_id"], "query": r["query"],
            "context": json.loads(r["context_json"]), "purpose": r["purpose"], "packet": json.loads(r["packet_json"]),
            "digest": r["digest"], "created_at": r["created_at"],
        }

    def list_reconstructions(self, carrier_id: str, limit: int = 50) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM reconstructions WHERE carrier_id=? ORDER BY created_at DESC LIMIT ?",
                (carrier_id, limit),
            ).fetchall()
        return [
            {
                "reconstruction_id": r["reconstruction_id"], "carrier_id": r["carrier_id"], "query": r["query"],
                "context": json.loads(r["context_json"]), "purpose": r["purpose"], "packet": json.loads(r["packet_json"]),
                "digest": r["digest"], "created_at": r["created_at"],
            }
            for r in rows
        ]

    def insert_self_state(self, state: dict[str, Any]) -> None:
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO self_states(state_id,carrier_id,parent_state_id,state_json,digest,created_at) VALUES(?,?,?,?,?,?)",
                (
                    state["state_id"], state["carrier_id"], state.get("parent_state_id"), canonical(state["state"]),
                    state["digest"], state["created_at"],
                ),
            )
        self.append_audit("self_state.insert", state["state_id"], {"carrier_id": state["carrier_id"], "digest": state["digest"], "parent_state_id": state.get("parent_state_id")})

    def latest_self_state(self, carrier_id: str) -> dict[str, Any] | None:
        with self.connect() as conn:
            r = conn.execute(
                "SELECT * FROM self_states WHERE carrier_id=? ORDER BY created_at DESC LIMIT 1", (carrier_id,)
            ).fetchone()
        if not r:
            return None
        return {
            "state_id": r["state_id"], "carrier_id": r["carrier_id"], "parent_state_id": r["parent_state_id"],
            "state": json.loads(r["state_json"]), "digest": r["digest"], "created_at": r["created_at"],
        }

    def list_self_states(self, carrier_id: str, limit: int = 50) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM self_states WHERE carrier_id=? ORDER BY created_at DESC LIMIT ?", (carrier_id, limit)
            ).fetchall()
        return [
            {
                "state_id": r["state_id"], "carrier_id": r["carrier_id"], "parent_state_id": r["parent_state_id"],
                "state": json.loads(r["state_json"]), "digest": r["digest"], "created_at": r["created_at"],
            }
            for r in rows
        ]

    def insert_action(self, action: dict[str, Any]) -> None:
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO actions(action_id,carrier_id,reconstruction_id,action_json,status,created_at) VALUES(?,?,?,?,?,?)",
                (
                    action["action_id"], action["carrier_id"], action.get("reconstruction_id"),
                    canonical(action["action"]), action.get("status", "planned"), action["created_at"],
                ),
            )
        self.append_audit("action.insert", action["action_id"], action)

    def update_action_status(self, action_id: str, status: str) -> None:
        with self.connect() as conn:
            conn.execute("UPDATE actions SET status=? WHERE action_id=?", (status, action_id))
        self.append_audit("action.status", action_id, {"status": status})

    def get_action(self, action_id: str) -> dict[str, Any] | None:
        with self.connect() as conn:
            r = conn.execute("SELECT * FROM actions WHERE action_id=?", (action_id,)).fetchone()
        if not r:
            return None
        return {
            "action_id": r["action_id"], "carrier_id": r["carrier_id"], "reconstruction_id": r["reconstruction_id"],
            "action": json.loads(r["action_json"]), "status": r["status"], "created_at": r["created_at"],
        }

    def list_actions(self, carrier_id: str, limit: int = 50) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute("SELECT * FROM actions WHERE carrier_id=? ORDER BY created_at DESC LIMIT ?", (carrier_id, limit)).fetchall()
        return [
            {"action_id": r["action_id"], "carrier_id": r["carrier_id"], "reconstruction_id": r["reconstruction_id"],
             "action": json.loads(r["action_json"]), "status": r["status"], "created_at": r["created_at"]}
            for r in rows
        ]

    def insert_outcome(self, outcome: dict[str, Any]) -> None:
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO outcomes(outcome_id,carrier_id,action_id,outcome_json,created_at) VALUES(?,?,?,?,?)",
                (outcome["outcome_id"], outcome["carrier_id"], outcome["action_id"], canonical(outcome["outcome"]), outcome["created_at"]),
            )
        self.append_audit("outcome.insert", outcome["outcome_id"], outcome)

    def list_outcomes(self, carrier_id: str, limit: int = 50) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute("SELECT * FROM outcomes WHERE carrier_id=? ORDER BY created_at DESC LIMIT ?", (carrier_id, limit)).fetchall()
        return [
            {"outcome_id": r["outcome_id"], "carrier_id": r["carrier_id"], "action_id": r["action_id"],
             "outcome": json.loads(r["outcome_json"]), "created_at": r["created_at"]}
            for r in rows
        ]

    def counts(self) -> dict[str, int]:
        with self.connect() as conn:
            result = {}
            for table in ("carriers", "records", "traces", "reconstructions", "self_states", "actions", "outcomes", "audit_events"):
                result[table] = int(conn.execute(f"SELECT COUNT(*) AS n FROM {table}").fetchone()["n"])
        return result
