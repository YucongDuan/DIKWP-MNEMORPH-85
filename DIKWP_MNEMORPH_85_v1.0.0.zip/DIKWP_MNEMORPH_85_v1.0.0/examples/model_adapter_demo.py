"""Minimal model-agnostic integration example.

The fake model stands in for any local/hosted LLM. Its output is kept as a proposal.
"""
from pathlib import Path
from mnemorph85.core import MemoryEngine
from mnemorph85.store import MemoryStore

store = MemoryStore(Path("var/model_adapter_demo.db"))
engine = MemoryEngine(store)
engine.bootstrap_demo(reset=True)

envelope = engine.memory_context_for_model(
    "demo-continuity",
    "Should the system repeat the historical high-output pattern?",
    context={"resource_state": "limited", "time": "now"},
    purpose="choose_next_action_without_identity_lock_in",
)

def fake_model(prompt: str) -> str:
    return "Proposal: consolidate the main path and test one externally reproducible result."

proposal = fake_model(envelope["model_prompt"])
print(envelope["adapter_contract"]["output_status"])
print(proposal)
print("No memory write has occurred. Observe a real-world outcome before reconsolidation.")
