# Scientific and engineering basis

MNEMORPH-85 uses memory neuroscience only as structural inspiration. It does not claim that software records are neuronal engrams or that functional reconstruction proves consciousness.

Primary/review references:

- Choucry, Nomoto & Inokuchi (2024), *Engram mechanisms of memory linking and identity*, https://doi.org/10.1038/s41583-024-00814-0
- Zaki & Cai (2025), *Memory engram stability and flexibility*, https://doi.org/10.1038/s41386-024-01979-z
- Fawcett et al. (2024), *Active intentional and unintentional forgetting*, https://doi.org/10.1038/s44159-024-00352-7
- Berry, Guhle & Davis (2024), *Active forgetting and neuropsychiatric diseases*, https://doi.org/10.1038/s41380-024-02521-9
- Williamson et al. (2025), *Learning-associated astrocyte ensembles regulate memory recall*, https://doi.org/10.1038/s41586-024-08170-w
- Packer et al. (2023), *MemGPT*, https://arxiv.org/abs/2310.08560
- Behrouz, Zhong & Mirrokni (2025), *Titans*, https://arxiv.org/abs/2501.00663

The engineering leap is governance and world-effect closure: exact archives are separated from lossy traces; recall is an explicit reconstruction; model outputs remain proposals; only observed outcomes can trigger reconsolidation.
