# 6. Deployment

## Local demonstration

```bash
python start_showcase.py
```

## Custom database

```bash
python start_showcase.py --db /secure/path/memory.db --port 8780
```

## Production prerequisites

- external authentication and role resolution;
- encrypted storage and key rotation;
- explicit memory-write consent;
- backup and restore tests;
- independent audit-chain export;
- model endpoint allowlist;
- action-authority separation;
- data retention and deletion policy;
- human factors and affected-world review.

The reference runtime is a research prototype, not a production identity or medical system.
