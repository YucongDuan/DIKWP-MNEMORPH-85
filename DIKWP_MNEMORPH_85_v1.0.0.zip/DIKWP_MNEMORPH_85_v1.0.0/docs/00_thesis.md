# 0. Thesis: Memory, not storage, is the operational boundary

A database can preserve a record for centuries without forming a point of view, changing an action or learning from an outcome. A transformer can retrieve exact passages from a vector index without creating a continuity that is changed by the world.

MNEMORPH-85 therefore defines an operational boundary:

```text
storage = preserved state that can be retrieved
memory = present reconstruction from traces that changes future behavior
living memory = memory that is revised by world effects and changes the continuing self/world model
```

This is not a universal definition of biological life or consciousness. It is a falsifiable engineering criterion for AI memory systems.
