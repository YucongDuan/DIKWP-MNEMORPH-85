# 4. Upgrading an existing LLM

Use `POST /api/model/context` or `MemoryEngine.memory_context_for_model()` before every model call.

The returned envelope includes:

- reconstructed memory core;
- differences and revisions;
- uncertainty;
- source lineage;
- current responsible action;
- an adapter contract.

The external model output must be stored as `PROPOSAL_AWAITING_WORLD_EFFECT`. After an authorized action, call `observe_outcome()` to create world-effect and correction traces and recompile the continuing self state.

The reference runtime intentionally does not include a network client. A deployment can wrap a local or hosted model, but must keep network use explicit and separately authorized.
