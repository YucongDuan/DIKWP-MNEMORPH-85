# 3. Memory states and failure modes

## Progressive states

- `ARCHIVE_ONLY`: records exist, no reconstructive recall;
- `RETRIEVAL_ASSISTANT`: relevant text is fetched, but self/action does not change;
- `RECONSTRUCTIVE_MEMORY`: context and counter-traces shape recall;
- `LIVING_MEMORY_CANDIDATE`: observed outcomes reconsolidate memory;
- `INTEGRATED_CONTINUITY`: cross-cycle memory, correction and successor transfer are active.

## Failure states

### ZOMBIE_REPLAY_LOOP
Repeated identical recall, no contrary evidence, no world effect, no self-state update.

### IDENTITY_LOCK_IN
New correction exists, but outdated memory continues to govern current action.

### MEMORY_COLONIZATION_HOLD
An external actor silently writes, merges or overrides memory without authorization.

Failure states apply to the current memory worldline only. They are not permanent labels for a carrier.
