# 7. Ninety-day pilot

## Recommended first scenario

A research or open-source team with changing priorities and a large archive.

## Days 0-15

- freeze source and consent boundaries;
- select 50-200 records;
- identify one identity-lock-in risk;
- define one world-effect measure.

## Days 16-35

- ingest exact records and traces;
- run context-contrast recalls;
- document omissions and counter-traces;
- test selective forgetting.

## Days 36-60

- connect recall to reversible actions;
- capture actual outcomes and affected-world feedback;
- measure correction latency and self-state updates.

## Days 61-90

- run successor transfer without the original model instance;
- test zombie replay and memory colonization attacks;
- publish negative results and corrections;
- decide whether the system is still retrieval-only or qualifies as a living-memory candidate.
