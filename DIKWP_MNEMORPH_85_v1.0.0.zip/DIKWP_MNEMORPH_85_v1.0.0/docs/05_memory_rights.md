# 5. Memory rights and anti-colonization

A memory system can dominate a carrier by silently defining its past, preferences or identity. MNEMORPH-85 therefore requires:

- purpose-specific write authorization;
- visible perspective and polarity;
- source and transformation lineage;
- access to counter-traces;
- correction and appeal;
- selective forgetting;
- private deletion where applicable;
- explicit identity non-equivalence for forks and digital twins.

Exact public historical records are corrected through supersession and tombstones. Private content can be physically removed while preserving a non-reversible audit event.
