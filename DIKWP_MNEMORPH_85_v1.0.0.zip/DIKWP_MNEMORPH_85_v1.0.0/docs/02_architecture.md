# 2. Architecture

```text
Exact Archive
   |  immutable bytes, digest, consent
   v
Trace Metabolism
   |  lossy compression, perspective, salience
   v
Reconstruction Workspace
   |  context + purpose + counter-memory + omissions
   v
Model Gateway
   |  any LLM returns a proposal
   v
Responsible Action Gate
   |  owner, deadline, authority, rollback
   v
World-Effect Observer
   |  actual result + affected-world feedback
   v
Reconsolidation / Self-State Lineage
```

The browser workbench is a local client. The Python standard-library server exposes JSON endpoints. SQLite stores records, traces, reconstructions, self states, actions, outcomes and an append-only audit hash chain.
