# 1. Formal model

## Exact record

```text
R_i = <id, carrier, source, time, bytes, digest, scope, consent>
```

## Memory trace

```text
T_j = <record_id, kind, transformed_content, perspective, polarity,
       salience, confidence, context, distortion, status>
```

A trace is explicitly non-identical to its source record.

## Reconstruction event

```text
M_t = Reconstruct({T_j}, query_t, context_t, purpose_t, self_state_t)
```

The event returns selected traces, counter-traces, omissions, uncertainty, a source map and one responsible action.

## Reconsolidation

```text
T_(t+1), S_(t+1) = Reconsolidate(M_t, action_t, observed_effect_t,
                                  affected_feedback_t, correction_t)
```

Without an observed effect, the model output remains a proposal and cannot become long-term memory.

## Living-memory vector

Twelve dimensions are stored separately. The runtime emits no scalar life or personhood score.
