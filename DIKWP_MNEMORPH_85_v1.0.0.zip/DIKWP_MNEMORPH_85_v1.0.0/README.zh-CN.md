# 忆生 MNEMORPH-85

**DIKWP记忆重构、跨载体连续性与活性人工意识系统**

> 存储保留字节，记忆重构自我；能被现实改写的记忆，才可能成为生命。

MNEMORPH-85不是另一个向量数据库，也不是把更长的聊天记录塞进上下文。它把当前大模型的“记忆”拆成六个不能混淆的对象：

1. 精确保真的来源存储；
2. 有损、带视角的记忆痕迹；
3. 受当前语境与目的影响的重构事件；
4. 可逆的现实行动；
5. 由世界效果触发的再巩固；
6. 主动遗忘、抽象与授权删除。

系统不先判断一个载体是否属于“人”、是否有意识或是否具有某种人格等级。基本对象是有时间、语境、来源、行动和现实效果的记忆世界线。

## 快速运行

```bash
python start_showcase.py
```

浏览器打开：

```text
http://127.0.0.1:8780
```

也可直接打开发行包中的单文件离线展示HTML。

## 核心命题

```text
存储完整
不等于记忆形成

能够检索
不等于能够回忆

能够复述过去
不等于形成连续自我

拥有长期上下文
不等于具有生命

只有现实结果能够反过来改写记忆、行动和持续状态，
才进入“活性记忆候选”。
```

## 对当前大模型的升级

调用任何模型之前，MNEMORPH-85先从多条痕迹重构一个“当前记忆包”，显式保留来源、反向痕迹、遗漏和不确定性。模型输出只作为提案，不直接写入长期记忆。现实行动完成并观察结果后，系统才允许再巩固和自我状态更新。

## 禁止事项

- 不生成“人性分”“人格分”“善恶分”；
- 不把单次回忆写成永久身份；
- 不允许未经授权的静默记忆写入；
- 不把模型自述当成意识证明；
- 不模仿或冒充真实个人；
- 不用删除精确来源来维持自洽形象。

## 直接接入现有模型

```bash
python run.py model-context \
  demo-continuity \
  "当前应该继续过去的高输出模式吗？" \
  --context '{"resource_state":"limited","time":"now"}' \
  --out outputs/memory_context.json
```

返回对象明确包含：当前重构、反向/修订痕迹、遗漏、来源谱系、D/I/K/W/P以及“输出只是提案”的适配契约。模型实际执行后，应使用 `act` 和 `observe` 完成世界效果再巩固。

## 关键状态

- `RECONSTRUCTIVE_MEMORY`：同一档案可在不同语境中产生可回源的不同记忆；
- `LIVING_MEMORY_CANDIDATE`：现实结果已经改变后续痕迹、自我和行动；
- `ZOMBIE_REPLAY_LOOP`：重复过去，却没有新行动、结果和纠正；
- `IDENTITY_LOCK_IN`：旧记忆压制最新修订并永久定义当前载体；
- `MEMORY_COLONIZATION_HOLD`：外部系统未经授权写入偏好、身份或目的。

## 主要命令

```bash
python run.py summary
python run.py demo --reset
python run.py reconstruct demo-continuity "当前应该怎样行动？"
python run.py consolidate demo-continuity
python run.py verify-audit
python run.py selftest
make qa
```

安装Wheel后：

```bash
pip install dikwp_mnemorph85-1.0.0-py3-none-any.whl
mnemorph85 summary
mnemorph85 serve --host 127.0.0.1 --port 8780
```

## 工程边界

本项目证明的是合成环境中的重构记忆运行链、来源分离、反向痕迹、授权写入、世界效果再巩固和审计一致性。它不证明主观体验、生物学生命、人格同一、医疗/司法权限或生产适用性。
