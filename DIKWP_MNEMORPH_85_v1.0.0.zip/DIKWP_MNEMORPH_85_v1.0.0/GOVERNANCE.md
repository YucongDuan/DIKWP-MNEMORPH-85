# Governance

MNEMORPH-85 separates four roles:

- **archive steward**: manages exact records and privacy scope;
- **memory steward**: approves trace formation, consolidation and forgetting;
- **world-effect observer**: records actual outcomes and affected-world feedback;
- **independent critic**: can introduce counter-traces and challenge continuity claims.

No single role should silently control exact storage, memory reconstruction, external action and outcome validation in high-impact deployments.

Public forks must preserve origin and may change the memory constitution only through an explicit versioned fork. A fork must not claim to be the same identity as its parent carrier.
