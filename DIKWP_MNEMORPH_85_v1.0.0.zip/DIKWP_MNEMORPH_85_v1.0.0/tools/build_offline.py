from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / "index.html").read_text(encoding="utf-8")
css = (ROOT / "assets" / "styles.css").read_text(encoding="utf-8")
js = (ROOT / "assets" / "app.js").read_text(encoding="utf-8")
logo = (ROOT / "assets" / "logo.svg").read_text(encoding="utf-8").replace("\n", "")
import urllib.parse
logo_uri = "data:image/svg+xml," + urllib.parse.quote(logo)
html = html.replace('<link rel="icon" href="assets/logo.svg" type="image/svg+xml">', f'<link rel="icon" href="{logo_uri}" type="image/svg+xml">')
html = html.replace('<link rel="stylesheet" href="assets/styles.css">', f'<style>{css}</style>')
html = html.replace('src="assets/logo.svg"', f'src="{logo_uri}"')
html = html.replace('<script src="assets/app.js"></script>', f'<script>{js}</script>')
out = ROOT / "忆生_MNEMORPH85_离线展示_双击打开_v1.0.0.html"
out.write_text(html, encoding="utf-8")
print(out)
