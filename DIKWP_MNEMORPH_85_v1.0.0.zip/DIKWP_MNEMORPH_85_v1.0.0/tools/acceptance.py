from __future__ import annotations

import json
from pathlib import Path
import socket
import tempfile
import threading
import time
from urllib.request import Request, urlopen

from http.server import ThreadingHTTPServer

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mnemorph85.server import App, Handler  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]

def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]

def get(port: int, path: str):
    with urlopen(f"http://127.0.0.1:{port}{path}") as r:
        return r.status, r.headers, r.read()

def post(port: int, path: str, payload: dict):
    req = Request(f"http://127.0.0.1:{port}{path}", data=json.dumps(payload).encode(), headers={"Content-Type": "application/json"}, method="POST")
    with urlopen(req) as r:
        return r.status, r.headers, json.loads(r.read().decode())

checks = []
def check(name, ok, detail=None): checks.append({"name": name, "passed": bool(ok), "detail": detail})

with tempfile.TemporaryDirectory() as td:
    port = free_port()
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.app = App(ROOT, Path(td) / "acceptance.db")  # type: ignore[attr-defined]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start(); time.sleep(.2)
    try:
        status, headers, body = get(port, "/api/health")
        health = json.loads(body)
        check("health", status == 200 and health["status"] == "ok", health)
        check("security_headers", headers.get("X-Frame-Options") == "DENY" and "object-src 'none'" in headers.get("Content-Security-Policy", ""))
        status, _, body = get(port, "/")
        check("frontend", status == 200 and b"MNEMORPH-85" in body)
        _, _, summary_body = get(port, "/api/summary")
        summary = json.loads(summary_body)
        check("demo_counts", summary["counts"]["traces"] >= 6, summary["counts"])
        _, _, packet = post(port, "/api/reconstruct", {"carrier_id":"demo-continuity","query":"当前应该怎么做？","context":{"resource_state":"limited"},"purpose":"choose"})
        check("reconstruction", packet["reconstruction_certificate"]["exact_storage_retrieval"] is False)
        check("counter_trace", len(packet["counter_and_revision_traces"]) >= 1)
        check("dikwp", packet["dikwp"]["semantic_continuity"]["vector"] == "11111")
        _, _, model_ctx = post(port, "/api/model/context", {"carrier_id":"demo-continuity","query":"what next"})
        check("model_adapter", model_ctx["adapter_contract"]["model_output_is_proposal_not_memory"])
        _, _, action = post(port, "/api/actions", {"carrier_id":"demo-continuity","reconstruction_id":packet["reconstruction_id"],"action_text":"推进一个可验证主线"})
        _, _, outcome = post(port, f"/api/actions/{action['action_id']}/outcome", {"carrier_id":"demo-continuity","actual_result":"合作方理解更快","affected_feedback":["支持负担下降"],"correction":"过去把数量等同于影响力需要修订"})
        check("world_effect_reconsolidation", outcome["correction_trace"] is not None)
        _, _, audit_body = get(port, "/api/audit/verify")
        audit = json.loads(audit_body)
        check("audit", audit["valid"], audit)
    finally:
        server.shutdown(); server.server_close()

report = {"system":"DIKWP MNEMORPH-85","passed":all(x["passed"] for x in checks),"checks":checks}
(ROOT / "outputs" / "acceptance.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(report, ensure_ascii=False, indent=2))
raise SystemExit(0 if report["passed"] else 1)
