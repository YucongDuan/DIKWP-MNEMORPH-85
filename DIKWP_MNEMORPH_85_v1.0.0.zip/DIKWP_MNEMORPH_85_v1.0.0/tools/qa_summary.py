from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
reports = {}
for name in ("static_audit", "acceptance"):
    p = ROOT / "outputs" / f"{name}.json"
    reports[name] = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {"passed": False, "error": "missing"}
report = {
    "system": "DIKWP MNEMORPH-85",
    "version": "1.0.0",
    "reports": reports,
    "passed": all(r.get("passed") for r in reports.values()),
    "note": "Unit-test count is reported by the release verification workflow.",
}
(ROOT / "outputs" / "qa_summary.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(report, ensure_ascii=False, indent=2))
raise SystemExit(0 if report["passed"] else 1)
