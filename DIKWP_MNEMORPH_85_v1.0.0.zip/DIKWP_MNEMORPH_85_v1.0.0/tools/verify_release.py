from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
checks = []
def check(name, ok, detail=None): checks.append({"name":name,"passed":bool(ok),"detail":detail})

manifest = ROOT / "MANIFEST.sha256"
check("manifest_exists", manifest.exists())
errors=[]
if manifest.exists():
    for line in manifest.read_text(encoding="utf-8").splitlines():
        if not line.strip(): continue
        expected, rel = line.split("  ", 1)
        p = ROOT / rel
        if not p.exists(): errors.append({"file":rel,"error":"missing"}); continue
        actual=hashlib.sha256(p.read_bytes()).hexdigest()
        if actual!=expected: errors.append({"file":rel,"expected":expected,"actual":actual})
check("manifest_hashes", not errors, {"entries":len(manifest.read_text().splitlines()) if manifest.exists() else 0,"errors":errors})
forbidden=[str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file() and ("__pycache__" in str(p) or p.suffix in {".pyc", ".db", ".log"})]
check("no_runtime_artifacts", not forbidden, forbidden)
proc=subprocess.run([sys.executable,"run.py","--db",str(ROOT/"var"/"verify.db"),"selftest"],cwd=ROOT,text=True,capture_output=True)
check("selftest",proc.returncode==0,{"stdout":proc.stdout[-2000:],"stderr":proc.stderr[-1000:]})
try:
    (ROOT/"var"/"verify.db").unlink(missing_ok=True)
    for suffix in ("-wal","-shm"):(ROOT/"var"/("verify.db"+suffix)).unlink(missing_ok=True)
except Exception: pass
report={"system":"DIKWP MNEMORPH-85","version":"1.0.0","passed":all(c["passed"] for c in checks),"checks":checks}
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(0 if report["passed"] else 1)
