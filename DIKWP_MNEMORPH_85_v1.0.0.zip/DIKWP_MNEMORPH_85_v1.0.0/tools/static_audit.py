from __future__ import annotations

import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
checks: list[dict] = []

def check(name: str, ok: bool, detail: object = None) -> None:
    checks.append({"name": name, "passed": bool(ok), "detail": detail})

required = [
    "README.md", "README.zh-CN.md", "LICENSE", "NOTICE", "MEMORY_CONSTITUTION.md",
    "run.py", "start_showcase.py", "index.html", "assets/app.js", "assets/styles.css",
    "mnemorph85/core.py", "mnemorph85/store.py", "mnemorph85/server.py", "mnemorph85/cli.py",
    "schemas/record.schema.json", "schemas/trace.schema.json", "schemas/reconstruction.schema.json",
]
for rel in required:
    check(f"required:{rel}", (ROOT / rel).exists())

all_text = "\n".join(
    p.read_text(encoding="utf-8", errors="ignore")
    for p in ROOT.rglob("*") if p.is_file() and p.suffix.lower() in {".py", ".js", ".html", ".css", ".md", ".json", ".toml"}
)
runtime_files = list((ROOT / "mnemorph85").glob("*.py")) + [ROOT / "run.py", ROOT / "start_showcase.py"]
runtime_text = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in runtime_files)
check("no_external_cdn", not re.search(r"https?://(?:cdn\.|unpkg|jsdelivr|fonts\.googleapis)", all_text, re.I))
check("no_shell_execution", "subprocess.Popen" not in runtime_text and "os.system(" not in runtime_text)
check("no_network_client_in_runtime", "requests." not in runtime_text and "urllib.request" not in runtime_text)
check("personhood_assessment_not_performed", "NOT_PERFORMED" in all_text)
check("no_humanity_ranking", not re.search(r"humanity_score\s*[:=]\s*[1-9]", all_text))
check("no_intrinsic_worth_ranking", not re.search(r"intrinsic_worth_score\s*[:=]\s*[1-9]", all_text))
check("silent_memory_write_forbidden", "silent_memory_write_forbidden" in all_text)
check("world_effect_required", "world_effect_required" in all_text)
check("counter_trace_integration", "counter_trace_integration" in all_text)
check("zombie_replay_state", "ZOMBIE_REPLAY_LOOP" in all_text)
check("identity_lock_in_state", "IDENTITY_LOCK_IN" in all_text)
check("memory_colonization_state", "MEMORY_COLONIZATION_HOLD" in all_text)
check("dikwp_11111", '"vector": "11111"' in all_text)
check("mesh85_debts", all(x in all_text for x in ["semantic_debt", "effect_debt", "affected_party_voice_debt"]))
check("offline_html_source_present", (ROOT / "index.html").exists())

# Parse JSON fixtures and schemas.
json_files = list((ROOT / "schemas").glob("*.json")) + list((ROOT / "examples").glob("*.json"))
errors = []
for p in json_files:
    try:
        json.loads(p.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append({"file": str(p.relative_to(ROOT)), "error": str(exc)})
check("json_parse", not errors, errors)

failed = [c for c in checks if not c["passed"]]
report = {"system": "DIKWP MNEMORPH-85", "checks": checks, "passed": not failed, "failed_count": len(failed)}
(ROOT / "outputs").mkdir(exist_ok=True)
(ROOT / "outputs" / "static_audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(report, ensure_ascii=False, indent=2))
sys.exit(0 if not failed else 1)
