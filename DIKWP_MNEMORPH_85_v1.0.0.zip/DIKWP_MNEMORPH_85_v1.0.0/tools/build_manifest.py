from __future__ import annotations

import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "MANIFEST.sha256"
EXCLUDE = {"MANIFEST.sha256"}

lines = []
for path in sorted(ROOT.rglob("*")):
    if not path.is_file():
        continue
    rel = path.relative_to(ROOT).as_posix()
    if rel in EXCLUDE or rel.startswith("var/") and path.name != ".gitkeep" or rel.startswith("outputs/") and path.name != ".gitkeep" or "__pycache__" in rel or rel.endswith(".pyc"):
        continue
    h = hashlib.sha256(path.read_bytes()).hexdigest()
    lines.append(f"{h}  {rel}")
OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
print(f"wrote {len(lines)} entries to {OUT}")
