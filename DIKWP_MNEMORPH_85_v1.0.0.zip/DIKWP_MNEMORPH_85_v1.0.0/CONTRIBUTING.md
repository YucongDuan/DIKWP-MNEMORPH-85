# Contributing

Contributions are welcome when they add at least one of:

- a new falsifiable memory invariant;
- a new external replication scenario;
- a better counter-trace integration test;
- a privacy or memory-sovereignty improvement;
- a new model adapter with network disabled by default;
- a measured world-effect loop.

A new abstraction alone is not sufficient. Include tests, failure conditions and a statement of what the contribution does not prove.
