# Changelog

## 1.0.0 - 2026-08-19

- exact archive and lossy trace separation;
- context-conditioned reconstruction;
- forced counter-trace integration;
- selective forgetting and consolidation;
- self-state lineage;
- world-effect reconsolidation;
- zombie replay, identity lock-in and memory-colonization detection;
- model-agnostic memory context gateway;
- MESH8.5 responsibility debts;
- offline showcase and complete QA.
