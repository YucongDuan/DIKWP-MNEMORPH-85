# Roadmap

## v1.1
- signed memory reconstruction certificates;
- adapter examples for local OpenAI-compatible endpoints;
- multi-carrier shared-memory negotiation;
- privacy-preserving trace export.

## v1.5
- independent benchmark for identity lock-in and zombie replay;
- human study of context-sensitive recall and correction latency;
- federated public seed library.

## v2.0
- cross-instance successor continuity;
- multi-model memory ecology;
- formal MESH8.5 world-effect conformance suite.
